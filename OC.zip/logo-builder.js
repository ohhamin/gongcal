// logo-builder.js — generates the OurCalendar "OC" interlocking-link mark as SVG.
// Exposes window.buildOCLogo(variant, opts)
(function () {
  const NAVY = '#14315A';

  function pt(cx, cy, r, deg) {
    const a = (deg * Math.PI) / 180;
    return [cx + r * Math.cos(a), cy + r * Math.sin(a)];
  }
  // arc from a0 -> a1 increasing angle (degrees), screen coords (y down)
  function arc(cx, cy, r, a0, a1) {
    const [x0, y0] = pt(cx, cy, r, a0);
    const [x1, y1] = pt(cx, cy, r, a1);
    const sweepDeg = (((a1 - a0) % 360) + 360) % 360;
    const large = sweepDeg > 180 ? 1 : 0;
    return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
  }

  // Default geometry (viewBox 0 0 120 120)
  function geom(o) {
    return Object.assign(
      {
        Ocx: 44, Ocy: 46, OR: 29,
        Ccx: 76, Ccy: 74, CR: 29,
        sw: 11,            // stroke weight
        // C arc: solid from a0 -> a1 (the gap of the C is the remaining wedge)
        Ca0: 48, Ca1: 312,
        // weave: where O passes OVER C (a short arc on O, centered angle on O)
        weaveCenter: 84,   // angle on O ring of the bottom crossing
        weaveSpan: 26,     // total span of the navy stamp
        gap: 2.2,          // background casing padding (=visual gap width-ish)
        color: NAVY,
        bg: '#ffffff',
        cap: 'round',
      },
      o || {}
    );
  }

  function buildOCLogo(variant, opts) {
    variant = variant || 'weave';
    const g = geom(opts);
    const { Ocx, Ocy, OR, Ccx, Ccy, CR, sw, Ca0, Ca1, color, bg, cap } = g;

    const Cpath = arc(Ccx, Ccy, CR, Ca0, Ca1);

    // weave stamp segment on O ring around the lower-left crossing
    const wc = g.weaveCenter;
    const ws = g.weaveSpan / 2;
    const casingPath = arc(Ocx, Ocy, OR, wc - ws, wc + ws);
    const stampPath = arc(Ocx, Ocy, OR, wc - ws + 2, wc + ws - 2);

    const common = `fill="none" stroke-linecap="${cap}"`;

    if (variant === 'gap') {
      // Flat "knockout" style: under-strands simply break with a bg gap at BOTH crossings.
      // O is the over-strand at upper crossing, C over-strand at lower crossing.
      // Implement by drawing both full, then bg casings at the under spots, then restamp the over.
      return `
<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" class="oc-svg">
  <g>
    <circle cx="${Ocx}" cy="${Ocy}" r="${OR}" fill="none" stroke="${color}" stroke-width="${sw}"/>
    <path d="${Cpath}" ${common} stroke="${color}" stroke-width="${sw}"/>
    <!-- C passes UNDER O at lower-left crossing: gap in C, restamp O -->
    <path d="${casingPath}" fill="none" stroke="${bg}" stroke-width="${sw + g.gap * 2}" stroke-linecap="round"/>
    <path d="${stampPath}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="butt"/>
  </g>
</svg>`;
    }

    // default: woven chain link (clean casing gap on one crossing)
    return `
<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" class="oc-svg">
  <g>
    <circle cx="${Ocx}" cy="${Ocy}" r="${OR}" fill="none" stroke="${color}" stroke-width="${sw}"/>
    <path d="${Cpath}" ${common} stroke="${color}" stroke-width="${sw}"/>
    <path d="${casingPath}" fill="none" stroke="${bg}" stroke-width="${sw + g.gap * 2}" stroke-linecap="round"/>
    <path d="${stampPath}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="butt"/>
  </g>
</svg>`;
  }

  window.buildOCLogo = buildOCLogo;
  window.OC_NAVY = NAVY;
})();
