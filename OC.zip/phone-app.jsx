// Main App — coordinates state + renders inside a device frame
function PhoneApp({ platform, shared }) {
  const theme = shared.theme;
  // Safe area for absolute status bar overlay (iOS overlays its status bar; Android lays it out in flow)
  const safeTop = platform === 'ios' ? 60 : 0;
  const [addOpen, setAddOpen] = React.useState(false);
  const [addRange, setAddRange] = React.useState(null);
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const openAdd = (range) => { setAddRange(range); setAddOpen(true); };

  // Tweaks panel can request add sheet via custom event
  React.useEffect(() => {
    const fn = (e) => openAdd(e.detail?.range || null);
    window.addEventListener('oc-open-add', fn);
    return () => window.removeEventListener('oc-open-add', fn);
  }, []);
  // Tweaks panel can request the confirm dialog
  React.useEffect(() => {
    const fn = () => setConfirmOpen(true);
    window.addEventListener('oc-open-confirm', fn);
    return () => window.removeEventListener('oc-open-confirm', fn);
  }, []);
  const safeBottom = platform === 'ios' ? 0 : 0; // tabs include their own padding
  return (
    <div style={{
      position: 'absolute', inset: 0, overflow: 'hidden',
      background: theme.bg,
      fontFamily: '"Pretendard", -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Segoe UI", Roboto, "Noto Sans KR", sans-serif',
      fontSize: `${shared.fontScale * 100}%`,
    }}>
      {shared.splash && (
        <Splash theme={theme} onEnter={() => shared.setSplash(false)} />
      )}
      <div style={{
        position: 'absolute',
        top: safeTop, left: 0, right: 0, bottom: platform === 'ios' ? 82 : 70,
      }}>
        {/* Cross-fade between tab screens */}
        <ScreenSwitcher tab={shared.tab}>
          <div data-tab="calendar" style={{ position: 'absolute', inset: 0 }}>
            <CalendarScreen
              theme={theme} platform={platform}
              selectedKey={shared.selectedKey}
              setSelectedKey={shared.setSelectedKey}
              openDate={(k) => { shared.setSelectedKey(k); shared.setPopupKey(k); }}
              onAddRange={(r) => openAdd(r)}
              events={shared.events}
              members={shared.members}
            />
          </div>
          <div data-tab="friends" style={{ position: 'absolute', inset: 0 }}>
            <FriendsScreen theme={theme} members={shared.members}/>
          </div>
          <div data-tab="settings" style={{ position: 'absolute', inset: 0 }}>
            <SettingsScreen
              theme={theme}
              dark={shared.dark} setDark={shared.setDark}
              notif={shared.notif} setNotif={shared.setNotif}
              weekStart={shared.weekStart} setWeekStart={shared.setWeekStart}
              fontScale={shared.fontScale}
            />
          </div>
        </ScreenSwitcher>
      </div>
      {/* Floating add (calendar tab only) */}
      {shared.tab === 'calendar' && !shared.splash && (
        <Press
          onClick={() => openAdd(null)}
          scale={0.9}
          style={{
            position: 'absolute', right: 16, bottom: platform === 'ios' ? 102 : 88,
            width: 52, height: 52, borderRadius: 26,
            background: theme.primary, color: theme.onPrimary,
            display: 'grid', placeItems: 'center', zIndex: 20,
            boxShadow: `0 8px 24px ${theme.primary}55, 0 2px 6px rgba(0,0,0,0.12)`,
          }}
        >
          <Icon name="plus" size={24} color={theme.onPrimary} />
        </Press>
      )}
      <BottomTabs tab={shared.tab} setTab={shared.setTab} theme={theme} platform={platform}/>
      <DatePopup
        theme={theme} platform={platform}
        dateKey={shared.popupKey || '2026-05-08'}
        events={shared.events} members={shared.members}
        open={!!shared.popupKey}
        onClose={() => shared.setPopupKey(null)}
        onAdd={() => { const k = shared.popupKey; shared.setPopupKey(null); openAdd({ start: k, end: k }); }}
      />
      <AddEventSheet
        theme={theme} platform={platform}
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={() => setAddOpen(false)}
        initialRange={addRange}
        members={shared.members}
      />
      <ConfirmModal
        theme={theme}
        open={confirmOpen}
        title="이 일정 초대를 수락하시겠습니까?"
        onClose={() => setConfirmOpen(false)}
        onDecline={() => setConfirmOpen(false)}
        onAccept={() => setConfirmOpen(false)}
      />
    </div>
  );
}

function ScreenSwitcher({ tab, children }) {
  const arr = React.Children.toArray(children);
  return (
    <>{arr.map((c, i) => {
      const id = c.props['data-tab'];
      const active = id === tab;
      return (
        <div key={id} style={{
          position: 'absolute', inset: 0,
          opacity: active ? 1 : 0,
          pointerEvents: active ? 'auto' : 'none',
          transform: active ? 'translateX(0)' : 'translateX(8px)',
          transition: 'opacity 240ms ease, transform 280ms cubic-bezier(.2,.7,.3,1)',
        }}>{c}</div>
      );
    })}</>
  );
}

Object.assign(window, { PhoneApp, ScreenSwitcher });
