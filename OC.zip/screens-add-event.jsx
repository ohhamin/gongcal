// ────────────────────────────────────────────────────────────
// AddEventSheet — full-height bottom sheet for creating an event
// ────────────────────────────────────────────────────────────
function AddEventSheet({ theme, platform, open, onClose, onSave, initialRange, members }) {
  const [render, setRender] = React.useState(open);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    if (open) {
      setRender(true);
      requestAnimationFrame(() => requestAnimationFrame(() => setShown(true)));
    } else if (render) {
      setShown(false);
      const t = setTimeout(() => setRender(false), 320);
      return () => clearTimeout(t);
    }
  }, [open]);

  // Form state
  const [title, setTitle] = React.useState('');
  const [details, setDetails] = React.useState('');
  const [allDay, setAllDay] = React.useState(false);
  const [visibility, setVisibility] = React.useState('public'); // 'public' | 'private'
  const [tipOpen, setTipOpen] = React.useState(false);
  const [startDate, setStartDate] = React.useState(initialRange?.start || '2026-05-27');
  const [endDate, setEndDate] = React.useState(initialRange?.end || '2026-05-27');
  const [startTime, setStartTime] = React.useState('오전 9:00');
  const [endTime, setEndTime] = React.useState('오후 10:00');
  const [attendees, setAttendees] = React.useState([
  { id: 'me', name: '나', role: '소유자' }]
  );

  // Reset when opening
  React.useEffect(() => {
    if (open) {
      setTitle('');
      setDetails('');
      setAllDay(false);
      setVisibility('public');
      setTipOpen(false);
      setStartDate(initialRange?.start || '2026-05-27');
      setEndDate(initialRange?.end || '2026-05-27');
      setStartTime('오전 9:00');
      setEndTime('오후 10:00');
      setAttendees([{ id: 'me', name: '나', role: '소유자' }]);
    }
  }, [open, initialRange]);

  const [invitePop, setInvitePop] = React.useState(false);

  if (!render) return null;

  const formatDateLabel = (key) => {
    const [y, m, d] = key.split('-').map(Number);
    return `${y}. ${String(m).padStart(2, '0')}. ${String(d).padStart(2, '0')}.`;
  };

  const hoursBetween = () => {
    // Best-effort: same date and end after start → label "(N시간)"
    if (startDate !== endDate) return '';
    // parse "오전 9:00" / "오후 10:00"
    const parse = (s) => {
      const m = s.match(/^(오전|오후)\s*(\d+):(\d{2})$/);
      if (!m) return null;
      let h = Number(m[2]);
      const min = Number(m[3]);
      if (m[1] === '오후' && h !== 12) h += 12;
      if (m[1] === '오전' && h === 12) h = 0;
      return h + min / 60;
    };
    const a = parse(startTime),b = parse(endTime);
    if (a == null || b == null || b <= a) return '';
    const diff = b - a;
    return diff === Math.floor(diff) ? `(${diff}시간)` : `(${diff.toFixed(1)}시간)`;
  };

  const submit = () => {
    onSave({
      title: title.trim() || '제목 없음',
      details, allDay, visibility,
      startDate, endDate, startTime, endTime,
      attendees
    });
  };

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 300
    }}>
      {/* backdrop */}
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0,
        background: theme.backdrop,
        opacity: shown ? 1 : 0,
        transition: 'opacity 280ms ease'
      }} />
      {/* sheet */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, top: platform === 'ios' ? 38 : 14,
        background: theme.surface,
        borderRadius: '24px 24px 0 0',
        boxShadow: theme.elevation,
        transform: shown ? 'translateY(0)' : 'translateY(100%)',
        transition: 'transform 420ms cubic-bezier(.2,.85,.25,1)',
        display: 'flex', flexDirection: 'column',
        overflow: 'hidden'
      }}>
        {/* handle */}
        <div style={{
          width: 36, height: 4, borderRadius: 2, background: theme.dividerStrong,
          margin: '10px auto 0'
        }} />
        {/* scrollable form */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 20px 10px' }}>
          <div style={{
            fontSize: 20, fontWeight: 700, letterSpacing: '-0.03em', color: theme.text,
            marginBottom: 14
          }}>일정 추가</div>

          {/* Title */}
          <Field theme={theme} label="일정 제목">
            <TextField theme={theme} value={title} onChange={setTitle} max={50} />
          </Field>

          {/* Details */}
          <Field theme={theme} label="세부일정">
            <TextField theme={theme} value={details} onChange={setDetails} max={500} multiline rows={2} />
          </Field>

          {/* Attendees */}
          <div style={{ marginBottom: 12 }}>
            <div style={{ ...{
                border: `1px solid ${theme.dividerStrong}`,
                borderRadius: 12, padding: 12,
                background: theme.surface, borderStyle: "solid", borderColor: "rgb(224, 224, 235)", borderImage: "initial", borderWidth: "0px 0px 1px 1px"
              }, border: "0px solid rgb(224, 224, 235)" }}>
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                marginBottom: 8
              }}>
                <div style={{ ...{ fontSize: 13.5, fontWeight: 700, letterSpacing: '-0.01em', color: theme.text }, color: "rgb(118, 118, 138)" }}>참석자</div>
                <Press onClick={() => setInvitePop(true)} scale={0.94} style={{
                  height: 28, padding: '0 12px', borderRadius: 8,
                  background: theme.text, color: theme.bg,
                  display: 'grid', placeItems: 'center',
                  fontSize: 11.5, fontWeight: 600, letterSpacing: '-0.01em'
                }}>초대</Press>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                {attendees.map((a) =>
                <div key={a.id} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  borderRadius: 9,
                  border: `1px solid ${theme.divider}`,
                  background: theme.surface, padding: "12px 14px"
                }}>
                    <div style={{ fontSize: 12.5, color: theme.text, letterSpacing: '-0.01em', fontWeight: 500 }}>{a.name}</div>
                    <div style={{ fontSize: 11, color: theme.textSecondary, letterSpacing: '-0.01em' }}>{a.role}</div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* All-day toggle row */}
          <div style={{ marginBottom: 10 }}>
            <Press onClick={() => setAllDay((v) => !v)} scale={0.99} ripple={false} style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '6px 2px'
            }}>
              <Checkbox theme={theme} on={allDay} />
              <span style={{ ...{ fontSize: 13.5, color: theme.text, letterSpacing: '-0.01em', fontWeight: 500 }, color: "rgb(118, 118, 138)" }}>하루 종일</span>
            </Press>
          </div>

          {/* Dates / Times */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 8 }}>
            <Field theme={theme} label="시작 날짜">
              <Selector theme={theme} value={formatDateLabel(startDate)} />
            </Field>
            <Field theme={theme} label={`시작 시간`}>
              <Selector theme={theme} value={startTime} disabled={allDay} />
            </Field>
            <Field theme={theme} label="종료 날짜">
              <Selector theme={theme} value={formatDateLabel(endDate)} />
            </Field>
            <Field theme={theme} label="종료 시간">
              <Selector theme={theme} value={`${endTime}${hoursBetween() ? ' ' + hoursBetween() : ''}`} disabled={allDay} />
            </Field>
          </div>

          {/* Visibility (공개/비공개) */}
          <div style={{ marginBottom: 4, padding: '2px 4px' }}>
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              gap: 12
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, position: 'relative' }}>
                <span style={{ fontSize: 13, color: theme.text, fontWeight: 600, letterSpacing: '-0.01em' }}>공개 설정</span>
                <Press onClick={() => setTipOpen((v) => !v)} scale={0.9} ripple={false} style={{
                  width: 18, height: 18, borderRadius: '50%',
                  border: `1px solid ${theme.dividerStrong}`,
                  color: theme.textSecondary, fontSize: 11, fontWeight: 600,
                  display: 'grid', placeItems: 'center'
                }}>?</Press>
                {tipOpen &&
                <Tooltip theme={theme} onClose={() => setTipOpen(false)}>
                    <b style={{ display: 'block', marginBottom: 4 }}>공유 캘린더 공개 설정</b>
                    일정은 다른 멤버의 캘린더에도 함께 표시되요.
                    <br /><br />
                    · <b>공개</b>: 제목·세부 내용을 모두 볼 수 있어요.
                    <br />
                    · <b>비공개</b>: ‘일정 있음’으로만 표시되고 상세 내용은 나만 볼 수 있어요.
                  </Tooltip>
                }
              </div>
              <VisibilityToggle theme={theme} value={visibility} onChange={setVisibility} />
            </div>
            <div style={{
              fontSize: 11.5, color: theme.textSecondary, letterSpacing: '-0.01em',
              marginTop: 8, paddingLeft: 2, lineHeight: 1.5
            }}>
              {visibility === 'public' ?
              '멤버 모두 제목·세부 일정을 볼 수 있어요.' :
              '멤버는 ‘일정 있음’으로만 볼 수 있고, 상세는 나만 알 수 있어요.'}
            </div>
          </div>

          {/* Visibility description trimmed */}
        </div>

        {/* Footer actions */}
        <div style={{
          padding: `12px 20px ${platform === 'ios' ? 24 : 14}px`,
          display: 'flex', justifyContent: 'flex-end', gap: 10,
          borderTop: `1px solid ${theme.divider}`,
          background: theme.surface
        }}>
          <Press onClick={onClose} scale={0.96} style={{
            height: 44, padding: '0 22px', borderRadius: 10,
            background: theme.surface2, color: theme.text,
            display: 'grid', placeItems: 'center',
            fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em'
          }}>취소</Press>
          <Press onClick={submit} scale={0.96} style={{
            height: 44, padding: '0 26px', borderRadius: 10,
            background: theme.primary, color: theme.onPrimary,
            display: 'grid', placeItems: 'center',
            fontSize: 14, fontWeight: 700, letterSpacing: '-0.01em',
            boxShadow: `0 4px 16px ${theme.primary}44`
          }}>저장</Press>
        </div>
      </div>

      {/* Invite popover */}
      {invitePop &&
      <InvitePopover theme={theme} members={members.filter((m) => !attendees.some((a) => a.name === m.name))}
      onClose={() => setInvitePop(false)}
      onPick={(m) => {
        setAttendees((prev) => [...prev, { id: m.id, name: m.name, role: '편집 가능' }]);
        setInvitePop(false);
      }} />

      }
    </div>);

}

function Field({ theme, label, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ ...{
          fontSize: 12.5, color: theme.textSecondary, letterSpacing: '-0.01em',
          marginBottom: 6, fontWeight: 500
        }, fontSize: "14px", fontWeight: "700", color: "rgb(118, 118, 138)" }}>{label}</div>
      {children}
    </div>);

}

function TextField({ theme, value, onChange, max, multiline, rows = 1 }) {
  const Tag = multiline ? 'textarea' : 'input';
  return (
    <div style={{ position: 'relative' }}>
      <Tag
        value={value}
        onChange={(e) => {
          const v = e.target.value;
          if (max && v.length > max) return;
          onChange(v);
        }}
        rows={multiline ? rows : undefined}
        style={{
          width: '100%', boxSizing: 'border-box',
          border: `1px solid ${theme.dividerStrong}`,
          borderRadius: 10,
          padding: multiline ? '12px 14px' : '12px 14px',
          fontSize: 14, color: theme.text, lineHeight: 1.5,
          background: theme.surface,
          outline: 'none',
          resize: 'none',
          fontFamily: 'inherit',
          letterSpacing: '-0.01em'
        }} />
      
      {max &&
      <div style={{
        textAlign: 'right', fontSize: 11.5, color: theme.textSecondary, marginTop: 6,
        letterSpacing: '-0.01em'
      }}>{value.length} / {max}</div>
      }
    </div>);

}

function Selector({ theme, value, disabled }) {
  return (
    <Press scale={0.98} ripple={false} disabled={disabled} style={{
      height: 44, padding: '0 12px 0 14px',
      border: `1px solid ${theme.dividerStrong}`,
      borderRadius: 10,
      background: theme.surface,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: 8,
      opacity: disabled ? 0.4 : 1
    }}>
      <span style={{
        fontSize: 13.5, color: theme.text, letterSpacing: '-0.01em',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
      }}>{value}</span>
      <Icon name="chevDown" size={16} color={theme.textSecondary} />
    </Press>);

}

function Checkbox({ theme, on }) {
  return (
    <div style={{
      width: 18, height: 18, borderRadius: 5,
      border: `1.5px solid ${on ? theme.primary : theme.dividerStrong}`,
      background: on ? theme.primary : 'transparent',
      display: 'grid', placeItems: 'center',
      transition: 'all 180ms ease'
    }}>
      {on && <Icon name="check" size={12} color={theme.onPrimary} />}
    </div>);

}

// Invite popover (small modal listing available members)
function InvitePopover({ theme, members, onClose, onPick }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 350,
      display: 'grid', placeItems: 'center'
    }}>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.4)'
      }} />
      <div style={{
        position: 'relative',
        width: 280, maxWidth: '85%',
        background: theme.surface, borderRadius: 16,
        boxShadow: theme.elevation, padding: 14
      }}>
        <div style={{
          fontSize: 14.5, fontWeight: 700, color: theme.text,
          letterSpacing: '-0.02em', padding: '4px 6px 12px'
        }}>참석자 초대</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {members.length === 0 ?
          <div style={{
            padding: '24px 12px', textAlign: 'center',
            fontSize: 12, color: theme.textTertiary, letterSpacing: '-0.01em'
          }}>초대할 수 있는 멤버가 없습니다.</div> :
          members.map((m) =>
          <Press key={m.id} onClick={() => onPick(m)} scale={0.98} style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '8px 10px', borderRadius: 10
          }}>
              <div style={{
              width: 30, height: 30, borderRadius: '50%',
              background: m.color, color: '#fff',
              display: 'grid', placeItems: 'center', fontSize: 14
            }}>{m.emoji}</div>
              <div style={{ flex: 1, fontSize: 13.5, fontWeight: 600, color: theme.text, letterSpacing: '-0.01em' }}>{m.name}</div>
              <Icon name="plus" size={16} color={theme.primary} />
            </Press>
          )}
        </div>
      </div>
    </div>);

}

// Visibility segmented toggle — 공개 / 비공개
function VisibilityToggle({ theme, value, onChange }) {
  const items = [
  { id: 'public', label: '공개' },
  { id: 'private', label: '비공개' }];

  const isPrivate = value === 'private';
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center',
      background: theme.surface2, borderRadius: 999, padding: 3,
      border: `1px solid ${theme.divider}`,
      position: 'relative'
    }}>
      <div style={{
        position: 'absolute', top: 3, bottom: 3,
        left: isPrivate ? '50%' : 3,
        width: 'calc(50% - 3px)',
        background: isPrivate ? theme.surface : theme.primary,
        border: isPrivate ? `1px solid ${theme.dividerStrong}` : 'none',
        borderRadius: 999,
        boxShadow: isPrivate ? 'none' : `0 2px 6px ${theme.primary}55`,
        transition: 'left 240ms cubic-bezier(.3,.85,.3,1), background 200ms ease'
      }} />
      {items.map((it) => {
        const active = value === it.id;
        return (
          <Press
            key={it.id}
            onClick={() => onChange(it.id)}
            scale={0.92} ripple={false}
            style={{
              position: 'relative', zIndex: 1,
              padding: '5px 16px', borderRadius: 999,
              color: active ? it.id === 'public' ? theme.onPrimary : theme.text : theme.textSecondary,
              fontSize: 12, fontWeight: 600, letterSpacing: '-0.01em',
              transition: 'color 220ms ease',
              display: 'flex', alignItems: 'center', gap: 4
            }}>
            
            <Icon name={it.id === 'public' ? 'sparkle' : 'lock'} size={11}
            color={active ? it.id === 'public' ? theme.onPrimary : theme.text : theme.textSecondary} />
            <span>{it.label}</span>
          </Press>);

      })}
    </div>);

}

// Small inline tooltip pinned to its trigger
function Tooltip({ theme, onClose, children }) {
  return (
    <>
      <div onClick={onClose} style={{
        position: 'fixed', inset: 0, zIndex: 410
      }} />
      <div style={{
        position: 'absolute', top: 'calc(100% + 8px)', left: -8,
        width: 240, padding: 12,
        background: theme.text, color: theme.bg,
        borderRadius: 12, boxShadow: theme.elevation,
        fontSize: 11.5, lineHeight: 1.5, letterSpacing: '-0.01em',
        zIndex: 420
      }}>
        <div style={{
          position: 'absolute', top: -6, left: 22, width: 12, height: 12,
          background: theme.text, transform: 'rotate(45deg)'
        }} />
        {children}
      </div>
    </>);

}

Object.assign(window, { AddEventSheet, Field, TextField, Selector, Checkbox, InvitePopover, VisibilityToggle, Tooltip });