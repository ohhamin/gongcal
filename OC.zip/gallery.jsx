// ════════════════════════════════════════════════════════════
// 우리캘린더 · 컴포넌트 라이브러리
// 앱에서 실제로 쓰이는 컴포넌트들을 카테고리별로 추출한 카탈로그.
// 모든 스펙먼은 실제 컴포넌트를 라이브로 렌더합니다.
// ════════════════════════════════════════════════════════════

// 문서(크롬) 팔레트 — 항상 라이트
const G = {
  bg: '#ECEEF3',
  card: '#FFFFFF',
  border: '#E4E6EE',
  borderStrong: '#D7DAE4',
  text: '#15171F',
  sub: '#6A6F7E',
  mono: '#9499A6',
  accent: '#1E3A8A',
};

const MONO = 'ui-monospace, "SF Mono", "JetBrains Mono", Menlo, monospace';

// ──────────────────────────────────────────────
// Layout primitives
// ──────────────────────────────────────────────
function Section({ id, index, title, en, desc, children }) {
  return (
    <section id={id} style={{ scrollMarginTop: 24, marginBottom: 56 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 6 }}>
        <span style={{ fontFamily: MONO, fontSize: 12, fontWeight: 600, color: G.mono }}>
          {String(index).padStart(2, '0')}
        </span>
        <h2 style={{ margin: 0, fontSize: 23, fontWeight: 700, letterSpacing: '-0.03em', color: G.text }}>
          {title}
        </h2>
        <span style={{ fontFamily: MONO, fontSize: 12, color: G.mono, letterSpacing: '0.02em' }}>{en}</span>
      </div>
      {desc && (
        <p style={{ margin: '0 0 20px 36px', fontSize: 13.5, color: G.sub, lineHeight: 1.55, maxWidth: 620, letterSpacing: '-0.01em' }}>
          {desc}
        </p>
      )}
      <div style={{
        marginLeft: 36, display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
        gap: 16,
      }}>
        {children}
      </div>
    </section>
  );
}

// A specimen card: name + description header, then a live preview area.
function Spec({ name, desc, children, span, pad = 28, previewBg, align = 'center', minH = 132 }) {
  return (
    <div style={{
      gridColumn: span ? `span ${span}` : 'auto',
      background: G.card, border: `1px solid ${G.border}`,
      borderRadius: 16, overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
    }}>
      <div style={{
        flex: 1, minHeight: minH, padding: pad,
        background: previewBg || 'var(--oc-pbg, #FAFBFD)',
        borderBottom: `1px solid ${G.border}`,
        display: 'flex', alignItems: align, justifyContent: 'center',
        gap: 14, flexWrap: 'wrap',
      }}>
        {children}
      </div>
      <div style={{ padding: '12px 16px 14px' }}>
        <div style={{ fontFamily: MONO, fontSize: 12.5, fontWeight: 600, color: G.text, letterSpacing: '-0.01em' }}>
          {name}
        </div>
        {desc && (
          <div style={{ fontSize: 12, color: G.sub, marginTop: 3, lineHeight: 1.5, letterSpacing: '-0.01em' }}>
            {desc}
          </div>
        )}
      </div>
    </div>
  );
}

// Contained overlay host — bounds position:absolute & position:fixed children
// via a transform containing block, so modals/popovers render inside the box.
function Stage({ theme, w = 280, h = 380, children }) {
  return (
    <div style={{
      position: 'relative', width: w, height: h,
      background: theme.bg, borderRadius: 22, overflow: 'hidden',
      border: `1px solid ${theme.divider}`,
      transform: 'translateZ(0)',
      boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
    }}>
      {children}
    </div>
  );
}

// ──────────────────────────────────────────────
// Interactive wrappers (hold local state)
// ──────────────────────────────────────────────
function DemoText({ theme, multiline, placeholder, initial = '' }) {
  const [v, setV] = React.useState(initial);
  return <TextField theme={theme} value={v} onChange={setV} max={multiline ? 500 : 50} multiline={multiline} rows={multiline ? 2 : 1} />;
}
function DemoCheckbox({ theme }) {
  const [on, setOn] = React.useState(true);
  return (
    <Press onClick={() => setOn(v => !v)} ripple={false} scale={0.97} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 2px' }}>
      <Checkbox theme={theme} on={on} />
      <span style={{ fontSize: 13.5, color: theme.text, fontWeight: 500, letterSpacing: '-0.01em' }}>하루 종일</span>
    </Press>
  );
}
function DemoToggle({ theme }) {
  const [on, setOn] = React.useState(true);
  return <Toggle theme={theme} on={on} onChange={setOn} />;
}
function DemoMini({ theme, accent }) {
  const [on, setOn] = React.useState(true);
  return (
    <Press onClick={() => setOn(v => !v)} ripple={false} scale={0.95}>
      <MiniToggle theme={theme} on={on} accent={accent} />
    </Press>
  );
}
function DemoVisibility({ theme }) {
  const [v, setV] = React.useState('public');
  return <VisibilityToggle theme={theme} value={v} onChange={setV} />;
}
function DemoScope({ theme }) {
  const [v, setV] = React.useState('group');
  return <ScopeToggle theme={theme} value={v} onChange={setV} />;
}
function DemoSegment({ theme }) {
  const [v, setV] = React.useState('group');
  return <SegmentTabs theme={theme} active={v} onChange={setV}
    tabs={[{ id: 'friends', label: '친구' }, { id: 'group', label: '그룹' }]} />;
}
function DemoBottomTabs({ theme }) {
  const [tab, setTab] = React.useState('friends');
  return (
    <div style={{ position: 'relative', width: 300, height: 78, background: theme.bg, borderRadius: 16, overflow: 'hidden', border: `1px solid ${theme.divider}` }}>
      <BottomTabs tab={tab} setTab={setTab} theme={theme} platform="android" />
    </div>
  );
}

// ──────────────────────────────────────────────
// Button specimens (the app's canonical button patterns)
// ──────────────────────────────────────────────
function BtnPrimary({ theme }) {
  return (
    <Press scale={0.96} style={{
      height: 44, padding: '0 26px', borderRadius: 10,
      background: theme.primary, color: theme.onPrimary,
      display: 'grid', placeItems: 'center',
      fontSize: 14, fontWeight: 700, letterSpacing: '-0.01em',
      boxShadow: `0 4px 16px ${theme.primary}44`,
    }}>저장</Press>
  );
}
function BtnSecondary({ theme }) {
  return (
    <Press scale={0.96} style={{
      height: 44, padding: '0 22px', borderRadius: 10,
      background: theme.surface2, color: theme.text,
      display: 'grid', placeItems: 'center',
      fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em',
    }}>취소</Press>
  );
}
function BtnDanger({ theme }) {
  const danger = '#E34545';
  const tint = theme.name === 'dark' ? 'rgba(227,69,69,0.18)' : '#FFEAEA';
  return (
    <Press scale={0.93} ripple={false} style={{
      padding: '9px 16px', borderRadius: 11,
      background: tint, color: danger,
      fontSize: 13.5, fontWeight: 700, letterSpacing: '-0.01em',
    }}>탈퇴</Press>
  );
}
function BtnPill({ theme }) {
  return (
    <Press scale={0.95} style={{
      padding: '10px 18px', borderRadius: 12,
      background: theme.primary, color: theme.onPrimary,
      display: 'flex', alignItems: 'center', gap: 5,
      fontSize: 14, fontWeight: 700, letterSpacing: '-0.01em',
    }}>
      <Icon name="plus" size={15} color={theme.onPrimary} />추가
    </Press>
  );
}
function BtnSmallSolid({ theme }) {
  return (
    <Press scale={0.94} style={{
      height: 30, padding: '0 14px', borderRadius: 8,
      background: theme.text, color: theme.bg,
      display: 'grid', placeItems: 'center',
      fontSize: 11.5, fontWeight: 600, letterSpacing: '-0.01em',
    }}>초대</Press>
  );
}
function BtnGhost({ theme }) {
  return (
    <Press scale={0.94} ripple={false} style={{
      fontSize: 12.5, color: theme.primary, fontWeight: 600,
      padding: '6px 10px', borderRadius: 8, letterSpacing: '-0.01em',
    }}>관리</Press>
  );
}
function BtnIcon({ theme }) {
  return (
    <Press scale={0.88} ripple={false} style={{
      width: 36, height: 36, borderRadius: 18,
      background: theme.surface2, display: 'grid', placeItems: 'center',
    }}>
      <Icon name="bell" size={17} color={theme.text} />
    </Press>
  );
}
function BtnCTA({ theme }) {
  return (
    <Press scale={0.97} style={{
      height: 50, padding: '0 22px', borderRadius: 12,
      background: theme.primary, color: theme.onPrimary,
      display: 'flex', alignItems: 'center', gap: 6,
      fontSize: 14.5, fontWeight: 600, letterSpacing: '-0.01em',
      boxShadow: `0 4px 18px ${theme.primary}33`,
    }}>
      <Icon name="plus" size={18} color={theme.onPrimary} />일정 추가
    </Press>
  );
}
function BtnFAB({ theme }) {
  return (
    <Press scale={0.9} aria-label="일정 추가" style={{
      width: 52, height: 52, borderRadius: 26,
      background: theme.primary, color: theme.onPrimary,
      display: 'grid', placeItems: 'center',
      boxShadow: `0 8px 24px ${theme.primary}55, 0 2px 6px rgba(0,0,0,0.12)`,
    }}>
      <Icon name="plus" size={24} color={theme.onPrimary} />
    </Press>
  );
}

// ──────────────────────────────────────────────
// List-row specimens (faithful to the in-app markup)
// ──────────────────────────────────────────────
function FriendRow({ theme, m }) {
  return (
    <Press scale={0.99} style={{
      width: '100%', boxSizing: 'border-box',
      display: 'flex', alignItems: 'center', gap: 12, padding: '14px 18px',
      background: theme.surface, borderRadius: 14, border: `1px solid ${theme.divider}`,
    }}>
      <div style={{ width: 44, height: 44, borderRadius: '50%', background: m.color, color: '#fff', display: 'grid', placeItems: 'center', fontSize: 18, fontWeight: 600 }}>{m.emoji}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14.5, fontWeight: 600, color: theme.text, letterSpacing: '-0.01em' }}>
          <span>{m.name}</span>
          {m.role === '주인' && <Icon name="crown" size={13} color={theme.primary} />}
        </div>
        <div style={{ fontSize: 11.5, color: theme.textSecondary, marginTop: 2, letterSpacing: '-0.01em' }}>{m.role}</div>
      </div>
      <Icon name="chevR" size={16} color={theme.textTertiary} />
    </Press>
  );
}
function GroupCard({ theme, name, role, count }) {
  const owner = role === '소유자';
  const danger = '#E34545';
  const tint = theme.name === 'dark' ? 'rgba(227,69,69,0.18)' : '#FFEAEA';
  return (
    <div style={{
      width: '100%', boxSizing: 'border-box',
      display: 'flex', alignItems: 'center', gap: 12,
      background: theme.surface, borderRadius: 16, border: `1px solid ${theme.divider}`,
      padding: '16px 16px 16px 18px',
    }}>
      <div style={{ width: 44, height: 44, borderRadius: 13, background: theme.tint, color: theme.primary, display: 'grid', placeItems: 'center', fontSize: 16, fontWeight: 700 }}>{name.slice(0, 1)}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15.5, fontWeight: 700, color: theme.text, letterSpacing: '-0.02em' }}>{name}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
          {owner && <Icon name="crown" size={12} color={theme.primary} />}
          <span style={{ fontSize: 12, fontWeight: 500, color: owner ? theme.primary : theme.textSecondary }}>{role}</span>
          <span style={{ fontSize: 12, color: theme.textTertiary }}>· 그룹원 {count}명</span>
        </div>
      </div>
      <Press scale={0.93} ripple={false} style={{ padding: '9px 16px', borderRadius: 11, background: tint, color: danger, fontSize: 13.5, fontWeight: 700 }}>{owner ? '삭제' : '탈퇴'}</Press>
    </div>
  );
}
function EventRow({ theme, dot, title, who, time }) {
  return (
    <Press scale={0.98} style={{
      width: '100%', boxSizing: 'border-box',
      padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 12,
      background: theme.surface, borderRadius: 14, border: `1px solid ${theme.divider}`,
    }}>
      <div style={{ width: 8, height: 8, borderRadius: '50%', background: dot, flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: theme.text, letterSpacing: '-0.01em' }}>{title}</div>
        <div style={{ fontSize: 11, color: theme.textSecondary, marginTop: 2 }}>{who}</div>
      </div>
      <div style={{ fontSize: 12, color: theme.textSecondary }}>{time}</div>
    </Press>
  );
}

// ──────────────────────────────────────────────
// Main catalog
// ──────────────────────────────────────────────
const ICON_NAMES = ['calendar', 'users', 'settings', 'plus', 'close', 'chevR', 'chevL', 'chevDown', 'bell', 'search', 'moon', 'sun', 'share', 'check', 'arrowR', 'user', 'lock', 'help', 'logout', 'drag', 'sparkle', 'pencil', 'crown'];

const NAV = [
  { id: 'foundations', label: '공통' },
  { id: 'buttons', label: '버튼' },
  { id: 'inputs', label: '인풋' },
  { id: 'tabs', label: '탭바' },
  { id: 'forms', label: '폼' },
  { id: 'lists', label: '리스트' },
  { id: 'modals', label: '모달' },
];

function Gallery() {
  const [dark, setDark] = React.useState(false);
  const theme = window.makeTheme(dark);
  const members = window.MEMBERS;

  const tokens = [
    ['primary', theme.primary], ['primaryStrong', theme.primaryStrong], ['tint', theme.tint],
    ['danger', '#E34545'], ['holiday', '#D63B3B'],
    ['text', theme.text], ['textSecondary', theme.textSecondary], ['textTertiary', theme.textTertiary],
    ['surface', theme.surface], ['surface2', theme.surface2], ['dividerStrong', theme.dividerStrong],
  ];

  return (
    <div style={{ minHeight: '100vh', background: G.bg, color: G.text, '--oc-pbg': dark ? theme.surface2 : '#FAFBFD' }}>
      {/* Header */}
      <header style={{
        position: 'sticky', top: 0, zIndex: 50,
        background: 'rgba(236,238,243,0.85)', backdropFilter: 'blur(12px)',
        borderBottom: `1px solid ${G.border}`,
      }}>
        <div style={{ maxWidth: 1080, margin: '0 auto', padding: '14px 24px', display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flex: 1, minWidth: 0 }}>
            <div style={{ width: 30, height: 30, borderRadius: 9, background: G.accent, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
              <Icon name="calendarFill" size={18} color="#fff" />
            </div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 14.5, fontWeight: 700, letterSpacing: '-0.02em', whiteSpace: 'nowrap' }}>우리캘린더 · 컴포넌트 라이브러리</div>
            </div>
          </div>
          <nav style={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            {NAV.map(n => (
              <a key={n.id} href={`#${n.id}`} style={{
                fontSize: 12.5, fontWeight: 600, color: G.sub, textDecoration: 'none',
                padding: '6px 10px', borderRadius: 8, letterSpacing: '-0.01em',
              }}>{n.label}</a>
            ))}
          </nav>
          <button onClick={() => setDark(d => !d)} style={{
            border: `1px solid ${G.borderStrong}`, background: G.card, cursor: 'pointer',
            borderRadius: 9, padding: '7px 12px', display: 'flex', alignItems: 'center', gap: 6,
            fontSize: 12.5, fontWeight: 600, color: G.text, letterSpacing: '-0.01em',
          }}>
            <Icon name={dark ? 'sun' : 'moon'} size={15} color={G.text} />
            {dark ? '라이트' : '다크'}
          </button>
        </div>
      </header>

      {/* Intro */}
      <div style={{ maxWidth: 1080, margin: '0 auto', padding: '40px 24px 28px' }}>
        <h1 style={{ margin: 0, fontSize: 38, fontWeight: 700, letterSpacing: '-0.04em', lineHeight: 1.1 }}>
          컴포넌트 라이브러리
        </h1>
        <p style={{ margin: '14px 0 0', fontSize: 15, color: G.sub, lineHeight: 1.6, maxWidth: 640, letterSpacing: '-0.01em' }}>
          우리캘린더 앱에서 실제로 사용 중인 UI 컴포넌트를 모달·리스트·폼·버튼·탭바·인풋·공통 7개 그룹으로 추출했습니다.
          모든 항목은 실제 컴포넌트를 그대로 렌더한 것으로, 우측 상단에서 라이트/다크를 전환해 확인할 수 있습니다.
        </p>
      </div>

      <main style={{ maxWidth: 1080, margin: '0 auto', padding: '12px 24px 80px' }}>

        {/* 01 · 공통 */}
        <Section id="foundations" index={1} title="공통 컴포넌트" en="Foundations"
          desc="모든 화면의 기반이 되는 색상 토큰, 아이콘 세트, 터치 피드백 래퍼와 브랜드 마크입니다.">
          <Spec name="Color Tokens" desc="테마 팔레트 — 라이트/다크 전환에 따라 값이 바뀝니다." span={2} align="flex-start" minH={0}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(96px,1fr))', gap: 10, width: '100%' }}>
              {tokens.map(([n, v]) => (
                <div key={n} style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                  <div style={{ height: 44, borderRadius: 9, background: v, border: `1px solid ${theme.divider}` }} />
                  <div style={{ fontFamily: MONO, fontSize: 10.5, color: G.text, fontWeight: 600 }}>{n}</div>
                  <div style={{ fontFamily: MONO, fontSize: 9.5, color: G.mono, textTransform: 'uppercase' }}>{v}</div>
                </div>
              ))}
            </div>
          </Spec>
          <Spec name="Icon" desc="24×24 스트로크 아이콘 세트 (Icon name=…)." span={2} align="flex-start" minH={0}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(74px,1fr))', gap: 8, width: '100%' }}>
              {ICON_NAMES.map(n => (
                <div key={n} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, padding: '12px 4px', borderRadius: 10, background: theme.surface2 }}>
                  <Icon name={n} size={22} color={theme.text} />
                  <span style={{ fontFamily: MONO, fontSize: 9.5, color: G.mono }}>{n}</span>
                </div>
              ))}
            </div>
          </Spec>
          <Spec name="Press" desc="스케일 + 리플 터치 피드백 래퍼. 모든 인터랙티브 요소의 베이스.">
            <Press style={{ height: 46, padding: '0 22px', borderRadius: 12, background: theme.surface, border: `1px solid ${theme.dividerStrong}`, display: 'grid', placeItems: 'center', fontSize: 13.5, fontWeight: 600, color: theme.text }}>눌러보세요</Press>
          </Spec>
          <Spec name="Avatar" desc="멤버 식별용 원형 아바타 (색상 + 이모지).">
            <div style={{ display: 'flex', gap: 10 }}>
              {members.map(m => (
                <div key={m.id} style={{ width: 44, height: 44, borderRadius: '50%', background: m.color, color: '#fff', display: 'grid', placeItems: 'center', fontSize: 18 }}>{m.emoji}</div>
              ))}
            </div>
          </Spec>
          <Spec name="Logo Mark" desc="스플래시 / 앱 아이콘 마크.">
            <div style={{ position: 'relative', width: 72, height: 72 }}>
              <div style={{ position: 'absolute', inset: 0, borderRadius: 18, background: theme.primary, boxShadow: `0 10px 26px ${theme.primary}55` }} />
              <div style={{ position: 'absolute', left: 13, top: 10, width: 46, height: 7, borderRadius: 4, background: theme.onPrimary, opacity: 0.55 }} />
              <div style={{ position: 'absolute', left: 13, top: 23, width: 20, height: 20, borderRadius: 5, background: theme.onPrimary }} />
              <div style={{ position: 'absolute', left: 36, top: 23, width: 23, height: 7, borderRadius: 4, background: theme.onPrimary, opacity: 0.7 }} />
              <div style={{ position: 'absolute', left: 36, top: 33, width: 16, height: 7, borderRadius: 4, background: theme.onPrimary, opacity: 0.4 }} />
              <div style={{ position: 'absolute', left: 13, top: 48, width: 46, height: 11, borderRadius: 6, background: theme.onPrimary, opacity: 0.85 }} />
            </div>
          </Spec>
        </Section>

        {/* 02 · 버튼 */}
        <Section id="buttons" index={2} title="버튼" en="Buttons"
          desc="앱 전반에서 반복되는 버튼 패턴. 모두 Press 위에 인라인 스타일로 구성됩니다.">
          <Spec name="Primary" desc="주요 동작 — 저장·확인."><BtnPrimary theme={theme} /></Spec>
          <Spec name="Secondary" desc="보조 동작 — 취소·닫기."><BtnSecondary theme={theme} /></Spec>
          <Spec name="Danger" desc="파괴적 동작 — 탈퇴·삭제."><BtnDanger theme={theme} /></Spec>
          <Spec name="Pill / Add" desc="아이콘 + 라벨 알약형 — 추가."><BtnPill theme={theme} /></Spec>
          <Spec name="Small Solid" desc="컴팩트 다크 버튼 — 초대."><BtnSmallSolid theme={theme} /></Spec>
          <Spec name="Ghost / Text" desc="저강조 텍스트 버튼 — 관리."><BtnGhost theme={theme} /></Spec>
          <Spec name="Icon Button" desc="원형 아이콘 버튼 — 알림."><BtnIcon theme={theme} /></Spec>
          <Spec name="FAB" desc="메인 화면 우측 하단 일정 추가 버튼."><BtnFAB theme={theme} /></Spec>
          <Spec name="CTA" desc="시트 하단 강조 버튼 — 일정 추가."><BtnCTA theme={theme} /></Spec>
        </Section>

        {/* 03 · 인풋 */}
        <Section id="inputs" index={3} title="인풋" en="Inputs"
          desc="값을 입력하거나 상태를 토글하는 폼 컨트롤. 클릭/입력해 직접 동작을 확인할 수 있습니다.">
          <Spec name="TextField" desc="단일 행 텍스트 입력." align="stretch">
            <div style={{ width: '100%' }}><DemoText theme={theme} placeholder="일정 제목" /></div>
          </Spec>
          <Spec name="TextField · multiline" desc="여러 줄 + 글자 수 카운터." align="stretch">
            <div style={{ width: '100%' }}><DemoText theme={theme} multiline initial="가족 모임 준비물 정리" /></div>
          </Spec>
          <Spec name="Selector" desc="값 표시 + 드롭다운 트리거." align="stretch">
            <div style={{ width: '100%' }}><Selector theme={theme} value="오전 9:00" /></div>
          </Spec>
          <Spec name="Checkbox" desc="체크박스 + 라벨 행."><DemoCheckbox theme={theme} /></Spec>
          <Spec name="Toggle" desc="설정용 스위치 (44×26)."><DemoToggle theme={theme} /></Spec>
          <Spec name="MiniToggle" desc="멤버별 컴팩트 스위치 (34×20).">
            <div style={{ display: 'flex', gap: 14 }}>
              <DemoMini theme={theme} accent={members[1].color} />
              <DemoMini theme={theme} accent={members[2].color} />
            </div>
          </Spec>
        </Section>

        {/* 04 · 탭바 */}
        <Section id="tabs" index={4} title="탭바 · 세그먼트" en="Tab bars & Segments"
          desc="화면·범위·옵션을 전환하는 내비게이션 컨트롤.">
          <Spec name="BottomTabs" desc="앱 하단 3-탭 내비게이션." span={2}><DemoBottomTabs theme={theme} /></Spec>
          <Spec name="SegmentTabs" desc="친구 / 그룹 세그먼트 토글." span={2} align="stretch">
            <div style={{ width: '100%', maxWidth: 320 }}><DemoSegment theme={theme} /></div>
          </Spec>
          <Spec name="ScopeToggle" desc="나 / 그룹 범위 토글 (아이콘형)."><DemoScope theme={theme} /></Spec>
          <Spec name="VisibilityToggle" desc="공개 / 비공개 세그먼트."><DemoVisibility theme={theme} /></Spec>
        </Section>

        {/* 05 · 폼 */}
        <Section id="forms" index={5} title="폼" en="Forms"
          desc="라벨·인풋·설명을 묶는 폼 빌딩 블록. 일정 추가 시트에서 조합되어 쓰입니다.">
          <Spec name="Field" desc="라벨 + 컨트롤 래퍼." span={2} align="stretch">
            <div style={{ width: '100%' }}>
              <Field theme={theme} label="일정 제목"><DemoText theme={theme} /></Field>
            </div>
          </Spec>
          <Spec name="Date / Time grid" desc="2×2 날짜·시간 셀렉터 그리드." span={2} align="stretch">
            <div style={{ width: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <Field theme={theme} label="시작 날짜"><Selector theme={theme} value="2026. 05. 27." /></Field>
              <Field theme={theme} label="시작 시간"><Selector theme={theme} value="오전 9:00" /></Field>
            </div>
          </Spec>
          <Spec name="Setting row" desc="라벨 + 설명 + 토글 (설정 화면)." span={2} align="stretch">
            <div style={{ width: '100%', background: theme.surface, border: `1px solid ${theme.divider}`, borderRadius: 12, overflow: 'hidden' }}>
              <SettingsRow theme={theme} icon="bell" label="알림" sub="일정 30분 전 알림" right={<Toggle theme={theme} on={true} onChange={() => {}} />} last />
            </div>
          </Spec>
          <Spec name="Visibility field" desc="설명 + 공개/비공개 토글 행." span={2} align="stretch">
            <div style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
              <span style={{ fontSize: 13, color: theme.text, fontWeight: 600, letterSpacing: '-0.01em' }}>공개 설정</span>
              <DemoVisibility theme={theme} />
            </div>
          </Spec>
        </Section>

        {/* 06 · 리스트 */}
        <Section id="lists" index={6} title="리스트" en="List rows"
          desc="목록을 구성하는 행 단위 컴포넌트. 친구·그룹·일정·설정 화면에서 사용됩니다.">
          <Spec name="Friend row" desc="아바타 + 이름 + 역할 (친구 탭)." span={2} align="stretch">
            <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <FriendRow theme={theme} m={members[0]} />
              <FriendRow theme={theme} m={members[1]} />
            </div>
          </Spec>
          <Spec name="Group card" desc="그룹명 + 역할 + 탈퇴/삭제 (그룹 탭)." span={2} align="stretch">
            <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 10 }}>
              <GroupCard theme={theme} name="우리집" role="소유자" count={3} />
              <GroupCard theme={theme} name="회사 팀" role="참여중" count={2} />
            </div>
          </Spec>
          <Spec name="Event row" desc="색상 점 + 제목 + 시간 (일정 시트)." span={2} align="stretch">
            <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <EventRow theme={theme} dot={members[1].color} title="카페 데이트" who="지우" time="오후 3시" />
              <EventRow theme={theme} dot={window.HOLIDAY_COLOR} title="어린이날" who="공휴일" time="종일" />
            </div>
          </Spec>
          <Spec name="Settings row" desc="아이콘 + 라벨 + 우측 값 (설정)." span={2} align="stretch">
            <div style={{ width: '100%', background: theme.surface, border: `1px solid ${theme.divider}`, borderRadius: 12, overflow: 'hidden' }}>
              <SettingsRow theme={theme} icon="user" label="프로필 편집" />
              <SettingsRow theme={theme} icon="lock" label="개인정보 보호" />
              <SettingsRow theme={theme} icon="logout" label="로그아웃" danger last />
            </div>
          </Spec>
        </Section>

        {/* 07 · 모달 */}
        <Section id="modals" index={7} title="모달 · 팝오버" en="Modals & Popovers"
          desc="화면 위에 떠서 작업을 처리하는 오버레이. 실제 컴포넌트를 디바이스 크기 박스 안에 라이브로 띄웠습니다.">
          <Spec name="DatePopup" desc="날짜별 일정 목록 바텀시트." align="center" minH={0}>
            <Stage theme={theme} w={280} h={380}>
              <DatePopup theme={theme} platform="android" dateKey="2026-05-10" events={window.SEED_EVENTS} members={members} open instant onClose={() => {}} onAdd={() => {}} />
            </Stage>
          </Spec>
          <Spec name="AddEventSheet" desc="일정 추가 풀 시트 (폼)." align="center" minH={0}>
            <Stage theme={theme} w={280} h={500}>
              <AddEventSheet theme={theme} platform="android" open instant onClose={() => {}} onSave={() => {}} initialRange={{ start: '2026-05-27', end: '2026-05-27' }} members={members} />
            </Stage>
          </Spec>
          <Spec name="InvitePopover" desc="참석자 초대 다이얼로그." align="center" minH={0}>
            <Stage theme={theme} w={280} h={320}>
              <InvitePopover theme={theme} members={members} onClose={() => {}} onPick={() => {}} />
            </Stage>
          </Spec>
          <Spec name="Tooltip" desc="도움말 말풍선." align="center" minH={0}>
            <Stage theme={theme} w={280} h={240}>
              <div style={{ position: 'absolute', top: 24, left: 24 }}>
                <div style={{ position: 'relative', display: 'inline-block' }}>
                  <div style={{ width: 18, height: 18, borderRadius: '50%', border: `1px solid ${theme.dividerStrong}`, color: theme.textSecondary, fontSize: 11, fontWeight: 600, display: 'grid', placeItems: 'center' }}>?</div>
                  <Tooltip theme={theme} onClose={() => {}}>
                    <b style={{ display: 'block', marginBottom: 4 }}>공유 캘린더 공개 설정</b>
                    일정은 다른 멤버의 캘린더에도 함께 표시되요.
                  </Tooltip>
                </div>
              </div>
            </Stage>
          </Spec>
          <Spec name="GroupDropdown" desc="캘린더 그룹 선택 드롭다운." align="center" minH={0}>
            <Stage theme={theme} w={280} h={360}>
              <div style={{ position: 'absolute', top: 18, right: 18 }}>
                <div style={{ position: 'relative' }}>
                  <GroupDropdown theme={theme} open instant onClose={() => {}} groups={window.CALENDAR_GROUPS} value="g1" onChange={() => {}} />
                </div>
              </div>
            </Stage>
          </Spec>
          <Spec name="MemberPopover" desc="멤버 일정 표시 토글 팝오버." align="center" minH={0}>
            <Stage theme={theme} w={280} h={360}>
              <div style={{ position: 'absolute', top: 18, right: 18 }}>
                <div style={{ position: 'relative' }}>
                  <MemberPopover theme={theme} open instant onClose={() => {}} members={members} hidden={new Set([members[3].name])} onToggle={() => {}} onAllOn={() => {}} onAllOff={() => {}} />
                </div>
              </div>
            </Stage>
          </Spec>
          <Spec name="ConfirmModal" desc="중앙 정렬 확인 다이얼로그 (수락거절 / 수락하기)." align="center" minH={0}>
            <Stage theme={theme} w={336} h={340}>
              <ConfirmModal theme={theme} open instant title="이 일정 초대를 수락하시겠습니까?" onClose={() => {}} onAccept={() => {}} onDecline={() => {}} />
            </Stage>
          </Spec>
        </Section>

        <footer style={{ marginTop: 24, paddingTop: 24, borderTop: `1px solid ${G.border}`, fontFamily: MONO, fontSize: 11.5, color: G.mono, letterSpacing: '0.02em' }}>
          우리캘린더 component library · 추출 컴포넌트 {(7)}개 그룹 · v1.0.0
        </footer>
      </main>
    </div>
  );
}

Object.assign(window, { Gallery });
