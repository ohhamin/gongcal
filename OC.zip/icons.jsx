// Minimal stroke icons — 24x24 default
function Icon({ name, size = 24, color = 'currentColor', strokeWidth = 1.8 }) {
  const p = { fill: 'none', stroke: color, strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    calendar: <g {...p}><rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/></g>,
    calendarFill: <g><rect x="3.5" y="5" width="17" height="15.5" rx="2.5" fill={color}/><path d="M3.5 9.5h17" stroke="white" strokeWidth="1.4"/><path d="M8 3v4M16 3v4" stroke={color} strokeWidth="1.8" strokeLinecap="round"/></g>,
    users: <g {...p}><circle cx="9" cy="9" r="3.4"/><path d="M3 19.5c0-3 2.7-5.4 6-5.4s6 2.4 6 5.4"/><circle cx="17" cy="8.5" r="2.6"/><path d="M16 14.2c2.7.3 4.7 2.4 4.7 5"/></g>,
    usersFill: <g><circle cx="9" cy="9" r="3.4" fill={color}/><path d="M3 19.5c0-3 2.7-5.4 6-5.4s6 2.4 6 5.4" fill={color} stroke={color} strokeWidth="1.4"/><circle cx="17" cy="8.5" r="2.6" fill={color}/><path d="M16 14.2c2.7.3 4.7 2.4 4.7 5" stroke={color} strokeWidth="1.6" fill="none" strokeLinecap="round"/></g>,
    settings: <g {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 14.7l-1.6-.9a6 6 0 000-3.6l1.6-.9-1.5-2.6-1.7.7a6 6 0 00-3.1-1.8L12.7 4h-3l-.4 1.6a6 6 0 00-3.1 1.8l-1.7-.7-1.5 2.6 1.6.9a6 6 0 000 3.6l-1.6.9 1.5 2.6 1.7-.7a6 6 0 003.1 1.8l.4 1.6h3l.4-1.6a6 6 0 003.1-1.8l1.7.7 1.5-2.6z"/></g>,
    settingsFill: <g><circle cx="12" cy="12" r="3" fill="white" stroke={color} strokeWidth="1.6"/><path d="M19.4 14.7l-1.6-.9a6 6 0 000-3.6l1.6-.9-1.5-2.6-1.7.7a6 6 0 00-3.1-1.8L12.7 4h-3l-.4 1.6a6 6 0 00-3.1 1.8l-1.7-.7-1.5 2.6 1.6.9a6 6 0 000 3.6l-1.6.9 1.5 2.6 1.7-.7a6 6 0 003.1 1.8l.4 1.6h3l.4-1.6a6 6 0 003.1-1.8l1.7.7 1.5-2.6z" fill={color}/></g>,
    plus: <path d="M12 5v14M5 12h14" {...p}/>,
    close: <path d="M6 6l12 12M18 6L6 18" {...p}/>,
    chevR: <path d="M9 5l7 7-7 7" {...p}/>,
    chevL: <path d="M15 5l-7 7 7 7" {...p}/>,
    chevDown: <path d="M5 9l7 7 7-7" {...p}/>,
    bell: <g {...p}><path d="M6 9a6 6 0 0112 0v4l1.5 3h-15L6 13V9z"/><path d="M10 19a2 2 0 004 0"/></g>,
    search: <g {...p}><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/></g>,
    moon: <path d="M20 14.5A8 8 0 1110.5 4a6.5 6.5 0 009.5 10.5z" {...p}/>,
    sun: <g {...p}><circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/></g>,
    share: <g {...p}><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4"/></g>,
    check: <path d="M5 12.5l5 5 9-11" {...p}/>,
    arrowR: <path d="M5 12h14M13 6l6 6-6 6" {...p}/>,
    user: <g {...p}><circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20c0-3.8 3.4-6.8 7.5-6.8s7.5 3 7.5 6.8"/></g>,
    lock: <g {...p}><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></g>,
    help: <g {...p}><circle cx="12" cy="12" r="8.5"/><path d="M9.5 9.5a2.5 2.5 0 015 0c0 1.7-2.5 2-2.5 4M12 17.5h.01"/></g>,
    logout: <g {...p}><path d="M15 4h3a2 2 0 012 2v12a2 2 0 01-2 2h-3"/><path d="M10 16l-4-4 4-4M6 12h11"/></g>,
    drag: <g {...p}><path d="M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01"/></g>,
    sparkle: <path d="M12 3v6M12 15v6M3 12h6M15 12h6M5.6 5.6l4.2 4.2M14.2 14.2l4.2 4.2M5.6 18.4l4.2-4.2M14.2 9.8l4.2-4.2" {...p}/>,
    pencil: <g {...p}><path d="M4 20h4l10-10-4-4L4 16v4z"/><path d="M14 6l4 4"/></g>,
    crown: <path d="M3 8l4 4 5-7 5 7 4-4-2 11H5L3 8z" {...p}/>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={{ display: 'block' }}>
      {paths[name]}
    </svg>
  );
}

Object.assign(window, { Icon });
