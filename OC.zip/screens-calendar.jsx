// ────────────────────────────────────────────────────────────
// Calendar grid + popup
// ────────────────────────────────────────────────────────────
const WEEKDAYS_KO = ['일', '월', '화', '수', '목', '금', '토'];
const MONTH_KO = ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'];

function fmtKey(y, m, d) {
  return `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
}

function buildMonthGrid(year, month) {
  // Sunday-first 6-row grid
  const first = new Date(year, month, 1);
  const startDow = first.getDay(); // 0=Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrev = new Date(year, month, 0).getDate();
  const cells = [];
  for (let i = 0; i < startDow; i++) {
    cells.push({ y: year, m: month - 1, d: daysInPrev - (startDow - 1 - i), out: true });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push({ y: year, m: month, d, out: false });
  }
  while (cells.length < 42) {
    const lastY = year, lastM = month + 1;
    const idx = cells.length - (startDow + daysInMonth) + 1;
    cells.push({ y: lastY, m: lastM, d: idx, out: true });
  }
  return cells;
}

function CalendarScreen({ theme, platform, selectedKey, setSelectedKey, openDate, events, members, onAddRange }) {
  // Fixed to May 2026 to match seed data; but allow simulated month switching with empty data
  const [cursor, setCursor] = React.useState({ y: 2026, m: 4 }); // May (0-indexed)
  const cells = React.useMemo(() => buildMonthGrid(cursor.y, cursor.m), [cursor]);
  const today = { y: 2026, m: 4, d: 8 }; // simulated today
  const goPrev = () => setCursor(c => c.m === 0 ? { y: c.y-1, m: 11 } : { y: c.y, m: c.m-1 });
  const goNext = () => setCursor(c => c.m === 11 ? { y: c.y+1, m: 0 } : { y: c.y, m: c.m+1 });
  const memberColors = Object.fromEntries(members.map(x => [x.name, x.color]));

  // ── New: calendar group dropdown + me/group toggle + member visibility popup
  const groups = window.CALENDAR_GROUPS;
  const [groupId, setGroupId] = React.useState('g1'); // default: 우리집
  const currentGroup = groups.find(g => g.id === groupId) || groups[0];
  const [scope, setScope] = React.useState('group'); // 'me' | 'group'
  // Members visible in this group (only for group mode)
  const groupMemberNames = currentGroup.members;
  const [hiddenMembers, setHiddenMembers] = React.useState(() => new Set());
  // When group changes, reset hidden set
  React.useEffect(() => { setHiddenMembers(new Set()); }, [groupId]);

  const [groupDropOpen, setGroupDropOpen] = React.useState(false);
  const [memberPopOpen, setMemberPopOpen] = React.useState(false);

  // Effective set of visible "who" names
  const visibleWho = React.useMemo(() => {
    if (scope === 'me') return new Set(['나', '공휴일']); // personal scope always shows holidays + 'me'
    return new Set([...groupMemberNames, '공휴일', '팀'].filter(n => !hiddenMembers.has(n)));
  }, [scope, groupId, hiddenMembers]);

  const filterEvents = (list) => list.filter(e => visibleWho.has(e.who));
  const visibleMemberCount = scope === 'me' ? 1 : groupMemberNames.filter(n => !hiddenMembers.has(n)).length;
  const totalMemberCount   = scope === 'me' ? 1 : groupMemberNames.length;

  // ── Long-press + drag range selection
  const gridRef = React.useRef(null);
  const holdTimerRef = React.useRef(null);
  const startKeyRef = React.useRef(null);
  const [dragRange, setDragRange] = React.useState(null);     // {start, end} while pressing
  const [pendingRange, setPendingRange] = React.useState(null); // after release (waiting for confirm)

  const cmp = (a, b) => a < b ? -1 : a > b ? 1 : 0;
  const inRange = (key, r) => r && (cmp(key, r.start) >= 0 && cmp(key, r.end) <= 0) || r && (cmp(key, r.end) >= 0 && cmp(key, r.start) <= 0);
  const normalize = (r) => r && (cmp(r.start, r.end) <= 0 ? r : { start: r.end, end: r.start });

  const keyAtPoint = (x, y) => {
    const el = document.elementFromPoint(x, y);
    if (!el) return null;
    const cell = el.closest('[data-day]');
    return cell ? cell.getAttribute('data-day') : null;
  };

  const cancelHold = () => {
    if (holdTimerRef.current && holdTimerRef.current !== 'active') {
      clearTimeout(holdTimerRef.current);
    }
    holdTimerRef.current = null;
  };

  const onGridDown = (e) => {
    if (pendingRange) return; // ignore during pending state
    const key = keyAtPoint(e.clientX, e.clientY);
    if (!key) return;
    startKeyRef.current = key;
    // schedule long-press detection
    holdTimerRef.current = setTimeout(() => {
      holdTimerRef.current = 'active';
      setDragRange({ start: key, end: key });
      try { navigator.vibrate && navigator.vibrate(15); } catch {}
    }, 600);
  };
  const onGridMove = (e) => {
    if (holdTimerRef.current === 'active') {
      const key = keyAtPoint(e.clientX, e.clientY);
      if (key) setDragRange(r => ({ start: r.start, end: key }));
      e.preventDefault();
    } else if (holdTimerRef.current) {
      const key = keyAtPoint(e.clientX, e.clientY);
      if (key && key !== startKeyRef.current) cancelHold();
    }
  };
  const onGridUp = (e) => {
    if (holdTimerRef.current === 'active') {
      setPendingRange(normalize(dragRange));
      setDragRange(null);
    } else {
      cancelHold();
    }
    holdTimerRef.current = null;
  };
  React.useEffect(() => () => cancelHold(), []);

  const cellIsInDrag = (key) => dragRange && inRange(key, normalize(dragRange));
  const cellIsInPending = (key) => pendingRange && inRange(key, pendingRange);

  const clearPending = () => setPendingRange(null);
  const confirmPendingAdd = () => {
    const range = pendingRange;
    setPendingRange(null);
    if (onAddRange) onAddRange(range);
  };

  // Format a Korean range label for the CTA
  const formatRange = (r) => {
    if (!r) return '';
    const [y1, m1, d1] = r.start.split('-').map(Number);
    const [y2, m2, d2] = r.end.split('-').map(Number);
    if (r.start === r.end) return `${m1}월 ${d1}일`;
    if (m1 === m2) return `${m1}월 ${d1}일 – ${d2}일`;
    return `${m1}/${d1} – ${m2}/${d2}`;
  };
  const rangeDayCount = (r) => {
    if (!r) return 0;
    const a = new Date(r.start), b = new Date(r.end);
    return Math.round((b - a) / 86400000) + 1;
  };

  return (
    <div style={{ position: 'absolute', inset: 0, background: theme.bg, display: 'flex', flexDirection: 'column', color: theme.text }}>
      {/* Header */}
      <div style={{
        padding: '4px 16px 10px', display: 'flex', flexDirection: 'column', gap: 8,
        flexShrink: 0, position: 'relative', zIndex: 5,
      }}>
        {/* Row 1 — month nav + calendar group dropdown + bell */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <Press onClick={goPrev} scale={0.85} ripple={false} style={{
            width: 32, height: 32, borderRadius: 16, display: 'grid', placeItems: 'center',
            color: theme.textSecondary,
          }}>
            <Icon name="chevL" size={18} color={theme.textSecondary} />
          </Press>
          <Press onClick={() => setCursor({ y: 2026, m: 4 })} scale={0.97} ripple={false} style={{
            display: 'flex', alignItems: 'center', gap: 4, padding: '4px 6px', borderRadius: 8,
          }}>
            <span style={{ fontSize: 18, fontWeight: 700, letterSpacing: '-0.03em', color: theme.text, whiteSpace: 'nowrap' }}>
              {cursor.y}년 {MONTH_KO[cursor.m]}
            </span>
            <Icon name="chevDown" size={15} color={theme.textSecondary} />
          </Press>
          <Press onClick={goNext} scale={0.85} ripple={false} style={{
            width: 32, height: 32, borderRadius: 16, display: 'grid', placeItems: 'center',
            color: theme.textSecondary,
          }}>
            <Icon name="chevR" size={18} color={theme.textSecondary} />
          </Press>
          <div style={{ flex: 1 }}/>
          {/* Calendar group dropdown */}
          <div style={{ position: 'relative' }}>
            <Press onClick={() => { setGroupDropOpen(v => !v); setMemberPopOpen(false); }} scale={0.95} ripple={false} style={{
              display: 'flex', alignItems: 'center', gap: 4,
              padding: '6px 10px 6px 12px', borderRadius: 10,
              border: `1px solid ${theme.dividerStrong}`,
              background: groupDropOpen ? theme.tint : theme.surface,
              color: theme.text, fontSize: 12.5, fontWeight: 600,
              letterSpacing: '-0.01em', whiteSpace: 'nowrap',
              transition: 'background 180ms ease',
            }}>
              <span style={{ marginRight: 2 }}>{currentGroup.icon}</span>
              <span>{currentGroup.label}</span>
              <Icon name="chevDown" size={14} color={theme.textSecondary} />
            </Press>
            <GroupDropdown
              open={groupDropOpen} onClose={() => setGroupDropOpen(false)}
              theme={theme} groups={groups} value={groupId}
              onChange={(id) => {
                setGroupId(id); setGroupDropOpen(false);
                setScope(id === 'mine' ? 'me' : 'group');
              }}
            />
          </div>
          <Press scale={0.88} ripple={false} style={{
            width: 32, height: 32, borderRadius: 16, marginLeft: 4,
            background: theme.surface2, display: 'grid', placeItems: 'center',
          }}>
            <Icon name="bell" size={16} color={theme.text} />
          </Press>
        </div>
        {/* Row 2 — 나/그룹 segmented toggle + 멤버 chip */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ScopeToggle theme={theme} value={scope} onChange={(v) => {
            setScope(v);
            if (v === 'me') setGroupId('mine');
            else if (groupId === 'mine') setGroupId('g1');
          }}/>
          <div style={{ flex: 1 }}/>
          <div style={{ position: 'relative' }}>
            <Press
              onClick={() => { setMemberPopOpen(v => !v); setGroupDropOpen(false); }}
              scale={0.94}
              style={{
                display: 'flex', alignItems: 'center', gap: 6, padding: '6px 10px',
                background: memberPopOpen ? theme.primary : theme.tint, borderRadius: 999,
                color: memberPopOpen ? theme.onPrimary : theme.primary,
                fontSize: 11.5, fontWeight: 600, letterSpacing: '-0.01em',
                whiteSpace: 'nowrap', flexShrink: 0,
                opacity: scope === 'me' ? 0.5 : 1,
                transition: 'background 180ms ease, color 180ms ease',
              }}
            >
              <div style={{ display: 'flex', marginRight: 2 }}>
                {groupMemberNames.slice(0, 3).map((n, i) => {
                  const m = members.find(x => x.name === n);
                  if (!m) return null;
                  const dim = hiddenMembers.has(m.name);
                  return (
                    <div key={m.id} style={{
                      width: 16, height: 16, borderRadius: '50%',
                      background: m.color, marginLeft: i ? -5 : 0,
                      border: `1.5px solid ${memberPopOpen ? theme.primary : theme.tint}`,
                      display: 'grid', placeItems: 'center',
                      fontSize: 9, color: '#fff', fontWeight: 600,
                      opacity: dim ? 0.35 : 1,
                      transition: 'opacity 180ms ease, border-color 180ms ease',
                    }}>{m.name[0]}</div>
                  );
                })}
              </div>
              <span>멤버 {visibleMemberCount}/{totalMemberCount}</span>
              <Icon name="chevDown" size={12} color={memberPopOpen ? theme.onPrimary : theme.primary}/>
            </Press>
            <MemberPopover
              open={memberPopOpen} onClose={() => setMemberPopOpen(false)}
              theme={theme} members={members.filter(m => groupMemberNames.includes(m.name))}
              hidden={hiddenMembers}
              onToggle={(name) => setHiddenMembers(prev => {
                const next = new Set(prev);
                if (next.has(name)) next.delete(name); else next.add(name);
                return next;
              })}
              onAllOn={() => setHiddenMembers(new Set())}
            />
          </div>
        </div>
      </div>

      {/* Weekday header */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(7,1fr)',
        padding: '4px 4px 8px',
        borderTop: `1px solid ${theme.divider}`,
        borderBottom: `1px solid ${theme.divider}`,
      }}>
        {WEEKDAYS_KO.map((w, i) => (
          <div key={w} style={{
            textAlign: 'center', fontSize: 11, fontWeight: 600, padding: '8px 0 4px',
            letterSpacing: '-0.01em',
            color: i === 0 ? theme.sunday : i === 6 ? theme.saturday : theme.textSecondary,
          }}>{w}</div>
        ))}
      </div>

      {/* Grid */}
      <div
        ref={gridRef}
        onPointerDown={onGridDown}
        onPointerMove={onGridMove}
        onPointerUp={onGridUp}
        onPointerCancel={() => { cancelHold(); setDragRange(null); }}
        style={{
          flex: 1, display: 'grid',
          gridTemplateColumns: 'repeat(7,1fr)',
          gridTemplateRows: 'repeat(6, minmax(0, 1fr))',
          touchAction: 'none',
          userSelect: 'none',
        }}
      >
        {cells.map((c, i) => {
          const key = fmtKey(c.y, c.m, c.d);
          const dow = i % 7;
          const isToday = !c.out && c.y === today.y && c.m === today.m && c.d === today.d;
          const isSelected = selectedKey === key && !c.out;
          const dayEvents = filterEvents(events[key] || []);
          const inDrag = !c.out && cellIsInDrag(key);
          const inPending = !c.out && cellIsInPending(key);
          const inAnyRange = inDrag || inPending;
          const numberColor = c.out
            ? theme.textTertiary
            : isToday ? theme.primary
            : dow === 0 ? theme.sunday : dow === 6 ? theme.saturday : theme.text;
          const clickable = !c.out;
          return (
            <div
              key={i}
              data-day={c.out ? '' : key}
              onClick={(e) => {
                if (pendingRange || dragRange) return;
                if (!clickable) return;
                setSelectedKey(key); openDate(key, c);
              }}
              style={{
                position: 'relative', padding: '6px 3px 0',
                borderRight: dow < 6 ? `1px solid ${theme.divider}` : 'none',
                borderBottom: `1px solid ${theme.divider}`,
                opacity: c.out ? 0.45 : 1,
                color: theme.text,
                cursor: clickable ? 'pointer' : 'default',
                background: inAnyRange ? (theme.name === 'dark' ? 'rgba(255,224,102,0.16)' : '#FFF8DB') : 'transparent',
                boxShadow: isSelected && !inAnyRange ? `inset 0 0 0 2px ${theme.dividerStrong}` : 'none',
                transition: 'background 220ms ease, box-shadow 180ms ease',
                WebkitTapHighlightColor: 'transparent',
                overflow: 'hidden',
                minHeight: 0,
              }}
            >
              {/* Day number */}
              <div style={{
                width: 26, height: 26, borderRadius: 7, margin: '0 auto',
                display: 'grid', placeItems: 'center',
                fontSize: 12.5, fontWeight: isToday ? 600 : 500,
                color: isToday && !c.out ? theme.onPrimary : numberColor,
                background: isToday && !c.out ? theme.primaryStrong : 'transparent',
                transition: 'all 180ms ease',
              }}>
                {c.d}
              </div>
              {/* Event pills */}
              <div style={{
                marginTop: 4, display: 'flex', flexDirection: 'column', gap: 2, padding: '0 2px',
              }}>
                {dayEvents.slice(0, 3).map((e, j) => {
                  const dotColor = memberColors[e.who] || theme.primary;
                  return (
                    <div key={j} style={{
                      height: 14, borderRadius: 3, padding: '0 4px',
                      background: theme.tint, color: theme.primary,
                      fontSize: 9, fontWeight: 500, letterSpacing: '-0.01em',
                      display: 'flex', alignItems: 'center', gap: 3,
                      overflow: 'hidden',
                    }}>
                      <span style={{
                        width: 4, height: 4, borderRadius: '50%', background: dotColor, flexShrink: 0,
                      }}/>
                      <span style={{
                        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      }}>{e.title}</span>
                    </div>
                  );
                })}
                {dayEvents.length > 3 && (
                  <div style={{
                    fontSize: 9, color: theme.textSecondary, padding: '0 4px', letterSpacing: '-0.01em',
                  }}>+{dayEvents.length - 3}</div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Pending range CTA — appears after long-press + drag release */}
      {pendingRange && (
        <RangeCTA
          theme={theme}
          label={formatRange(pendingRange)}
          dayCount={rangeDayCount(pendingRange)}
          onCancel={clearPending}
          onConfirm={confirmPendingAdd}
        />
      )}
    </div>
  );
}

function RangeCTA({ theme, label, dayCount, onCancel, onConfirm }) {
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    const t = requestAnimationFrame(() => setShown(true));
    return () => cancelAnimationFrame(t);
  }, []);
  return (
    <div style={{
      position: 'absolute', left: 12, right: 12, bottom: 16,
      background: theme.surface,
      borderRadius: 16,
      boxShadow: theme.elevation,
      padding: '10px 10px 10px 16px',
      display: 'flex', alignItems: 'center', gap: 10,
      border: `1px solid ${theme.divider}`,
      transform: shown ? 'translateY(0)' : 'translateY(24px)',
      opacity: shown ? 1 : 0,
      transition: 'transform 320ms cubic-bezier(.2,.85,.25,1), opacity 200ms ease',
      zIndex: 25,
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10,
        background: '#FFF3B0', color: '#7A5B00',
        display: 'grid', placeItems: 'center',
        flexShrink: 0, fontSize: 16,
      }}>
        <Icon name="calendar" size={18} color="#7A5B00"/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 13, fontWeight: 700, color: theme.text,
          letterSpacing: '-0.02em',
        }}>{label}</div>
        <div style={{
          fontSize: 11, color: theme.textSecondary, marginTop: 1,
          letterSpacing: '-0.01em',
        }}>{dayCount}일 선택됨 · 일정을 추가할까요?</div>
      </div>
      <Press onClick={onCancel} ripple={false} scale={0.92} style={{
        width: 34, height: 34, borderRadius: 17,
        background: theme.surface2, display: 'grid', placeItems: 'center',
        color: theme.textSecondary, flexShrink: 0,
      }}>
        <Icon name="close" size={16} color={theme.textSecondary}/>
      </Press>
      <Press onClick={onConfirm} scale={0.95} style={{
        height: 38, padding: '0 16px', borderRadius: 12,
        background: theme.primary, color: theme.onPrimary,
        display: 'flex', alignItems: 'center', gap: 6,
        fontSize: 13, fontWeight: 600, letterSpacing: '-0.01em',
        boxShadow: `0 4px 16px ${theme.primary}55`,
        flexShrink: 0,
      }}>
        <Icon name="plus" size={16} color={theme.onPrimary}/>
        <span>일정 추가</span>
      </Press>
    </div>
  );
}

// Bottom-sheet popup (slide-up from bottom, backdrop fade)
function DatePopup({ theme, platform, dateKey, events, members, open, onClose, onAdd }) {
  // mount/unmount with animation
  const [render, setRender] = React.useState(open);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    if (open) {
      setRender(true);
      requestAnimationFrame(() => requestAnimationFrame(() => setShown(true)));
    } else if (render) {
      setShown(false);
      const t = setTimeout(() => setRender(false), 320);
      return () => clearTimeout(t);
    }
  }, [open]);
  if (!render) return null;

  const memberColors = Object.fromEntries(members.map(x => [x.name, x.color]));
  const list = events[dateKey] || [];
  const [y, m, d] = dateKey.split('-').map(Number);
  const dow = WEEKDAYS_KO[new Date(y, m-1, d).getDay()];
  const empty = list.length === 0;
  const sheetH = empty ? 240 : Math.min(540, 144 + list.length * 56);

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 200,
      pointerEvents: 'auto',
    }}>
      {/* backdrop */}
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0,
        background: theme.backdrop,
        opacity: shown ? 1 : 0,
        transition: 'opacity 280ms ease',
      }}/>
      {/* sheet */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        height: sheetH,
        background: theme.surface,
        borderRadius: '20px 20px 0 0',
        boxShadow: theme.elevation,
        transform: shown ? 'translateY(0)' : 'translateY(100%)',
        transition: 'transform 360ms cubic-bezier(.2,.85,.25,1)',
        display: 'flex', flexDirection: 'column',
        paddingBottom: platform === 'ios' ? 28 : 12,
      }}>
        {/* drag handle */}
        <div style={{
          width: 36, height: 4, borderRadius: 2, background: theme.dividerStrong,
          margin: '12px auto 0',
        }}/>
        {/* header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '14px 16px 14px 20px',
          borderBottom: `1px solid ${theme.divider}`,
        }}>
          <div style={{ fontSize: 16, fontWeight: 600, letterSpacing: '-0.02em', color: theme.text }}>
            {y}년 {m}월 {d}일 <span style={{ color: theme.textSecondary, fontWeight: 500 }}>({dow})</span>
          </div>
          <Press onClick={onClose} scale={0.9} ripple={false} style={{
            padding: '6px 12px', borderRadius: 8,
            background: theme.surface2, color: theme.textSecondary,
            fontSize: 12, fontWeight: 500,
          }}>닫기</Press>
        </div>
        {/* list */}
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {empty ? (
            <div style={{
              padding: '36px 20px 24px', textAlign: 'center',
              fontSize: 13, color: theme.textTertiary, letterSpacing: '-0.01em',
            }}>
              <div style={{ marginBottom: 4 }}>일정이 없습니다.</div>
              <div style={{ fontSize: 11, color: theme.textTertiary }}>이 날을 우리만의 시간으로 채워볼까요?</div>
            </div>
          ) : list.map((e, i) => (
            <Press key={i} scale={0.98} style={{
              padding: '16px 20px',
              display: 'flex', alignItems: 'center', gap: 12,
              borderBottom: i < list.length - 1 ? `1px solid ${theme.divider}` : 'none',
            }}>
              <div style={{
                width: 8, height: 8, borderRadius: '50%',
                background: memberColors[e.who] || theme.primary,
                flexShrink: 0,
              }}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  fontSize: 14, fontWeight: 600, color: theme.text,
                  letterSpacing: '-0.01em',
                }}>{e.title}</div>
                <div style={{
                  fontSize: 11, color: theme.textSecondary, marginTop: 2,
                  letterSpacing: '-0.01em',
                }}>{e.who}</div>
              </div>
              <div style={{
                fontSize: 12, color: theme.textSecondary,
                letterSpacing: '-0.01em',
              }}>{e.time}</div>
            </Press>
          ))}
        </div>
        {/* add button */}
        <div style={{ padding: '12px 16px 8px' }}>
          <Press onClick={onAdd} scale={0.97} style={{
            height: 50, borderRadius: 12,
            background: theme.primary, color: theme.onPrimary,
            display: 'grid', placeItems: 'center',
            fontSize: 14.5, fontWeight: 600, letterSpacing: '-0.01em',
            boxShadow: `0 4px 18px ${theme.primary}33`,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Icon name="plus" size={18} color={theme.onPrimary} />
              <span>일정 추가</span>
            </div>
          </Press>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CalendarScreen, DatePopup, buildMonthGrid, fmtKey, WEEKDAYS_KO, MONTH_KO });

// ────────────────────────────────────────────────────────────
// Sub-components: dropdowns, toggles, popovers
// ────────────────────────────────────────────────────────────

// 나 / 그룹 segmented toggle (icon-based)
function ScopeToggle({ theme, value, onChange }) {
  const sel = value;
  const items = [
    { id: 'me',    icon: 'user' ,  label: '나' },
    { id: 'group', icon: 'users',  label: '그룹' },
  ];
  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      background: theme.surface2, borderRadius: 999, padding: 3,
      border: `1px solid ${theme.divider}`,
      position: 'relative',
    }}>
      {/* sliding pill */}
      <div style={{
        position: 'absolute', top: 3, left: sel === 'me' ? 3 : 'calc(50% + 0px)',
        width: 'calc(50% - 3px)', height: 'calc(100% - 6px)',
        background: theme.primary, borderRadius: 999,
        transition: 'left 240ms cubic-bezier(.3,.85,.3,1)',
        boxShadow: `0 2px 6px ${theme.primary}55`,
      }}/>
      {items.map(it => {
        const active = sel === it.id;
        return (
          <Press
            key={it.id}
            onClick={() => onChange(it.id)}
            scale={0.92} ripple={false}
            style={{
              position: 'relative', zIndex: 1,
              padding: '5px 14px', borderRadius: 999,
              display: 'flex', alignItems: 'center', gap: 5,
              color: active ? theme.onPrimary : theme.textSecondary,
              fontSize: 11.5, fontWeight: 600, letterSpacing: '-0.01em',
              transition: 'color 220ms ease',
            }}
          >
            <Icon name={it.icon} size={14} color={active ? theme.onPrimary : theme.textSecondary}/>
            <span>{it.label}</span>
          </Press>
        );
      })}
    </div>
  );
}

// 캘린더 그룹 선택 드롭다운
function GroupDropdown({ open, onClose, theme, groups, value, onChange }) {
  const [render, setRender] = React.useState(open);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    if (open) { setRender(true); requestAnimationFrame(() => requestAnimationFrame(() => setShown(true))); }
    else if (render) { setShown(false); const t = setTimeout(() => setRender(false), 200); return () => clearTimeout(t); }
  }, [open]);
  if (!render) return null;
  return (
    <>
      {/* invisible scrim to dismiss */}
      <div onClick={onClose} style={{
        position: 'fixed', inset: 0, zIndex: 60,
      }}/>
      <div style={{
        position: 'absolute', top: 'calc(100% + 6px)', right: 0,
        minWidth: 200,
        background: theme.surface,
        border: `1px solid ${theme.divider}`,
        borderRadius: 14,
        boxShadow: theme.elevation,
        padding: 6,
        zIndex: 70,
        opacity: shown ? 1 : 0,
        transform: shown ? 'translateY(0) scale(1)' : 'translateY(-6px) scale(0.96)',
        transformOrigin: 'top right',
        transition: 'opacity 180ms ease, transform 220ms cubic-bezier(.2,.85,.3,1)',
      }}>
        {groups.map(g => {
          const active = g.id === value;
          return (
            <Press key={g.id} onClick={() => onChange(g.id)} scale={0.98} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 12px', borderRadius: 10,
              background: active ? theme.tint : 'transparent',
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 9,
                background: active ? theme.primary : theme.surface2,
                display: 'grid', placeItems: 'center',
                fontSize: 16,
              }}>{g.icon}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  fontSize: 13, fontWeight: 600,
                  color: active ? theme.primary : theme.text,
                  letterSpacing: '-0.01em',
                }}>{g.label}</div>
                <div style={{ fontSize: 10.5, color: theme.textSecondary, marginTop: 1, letterSpacing: '-0.01em' }}>
                  {g.sub}
                </div>
              </div>
              {active && <Icon name="check" size={16} color={theme.primary}/>}
            </Press>
          );
        })}
        <div style={{ height: 1, background: theme.divider, margin: '4px 8px' }}/>
        <Press scale={0.98} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          padding: '10px 12px', borderRadius: 10,
          color: theme.textSecondary, fontSize: 12, fontWeight: 500,
          letterSpacing: '-0.01em',
        }}>
          <Icon name="plus" size={16} color={theme.textSecondary}/>
          <span>새 그룹 만들기</span>
        </Press>
      </div>
    </>
  );
}

// 멤버 표시 토글 팝오버 — 멤버 칩 바로 아래
function MemberPopover({ open, onClose, theme, members, hidden, onToggle, onAllOn }) {
  const [render, setRender] = React.useState(open);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    if (open) { setRender(true); requestAnimationFrame(() => requestAnimationFrame(() => setShown(true))); }
    else if (render) { setShown(false); const t = setTimeout(() => setRender(false), 200); return () => clearTimeout(t); }
  }, [open]);
  if (!render) return null;
  return (
    <>
      <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 60 }}/>
      <div style={{
        position: 'absolute', top: 'calc(100% + 8px)', right: 0,
        width: 220,
        background: theme.surface,
        border: `1px solid ${theme.divider}`,
        borderRadius: 14,
        boxShadow: theme.elevation,
        zIndex: 70,
        overflow: 'hidden',
        opacity: shown ? 1 : 0,
        transform: shown ? 'translateY(0) scale(1)' : 'translateY(-6px) scale(0.96)',
        transformOrigin: 'top right',
        transition: 'opacity 180ms ease, transform 220ms cubic-bezier(.2,.85,.3,1)',
      }}>
        {/* arrow */}
        <div style={{
          position: 'absolute', top: -6, right: 22, width: 12, height: 12,
          background: theme.surface,
          borderTop: `1px solid ${theme.divider}`,
          borderLeft: `1px solid ${theme.divider}`,
          transform: 'rotate(45deg)',
        }}/>
        <div style={{
          padding: '12px 14px 8px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div style={{
            fontSize: 11.5, fontWeight: 600, color: theme.textSecondary,
            letterSpacing: '0.04em', textTransform: 'uppercase',
          }}>멤버 일정 표시</div>
          <Press onClick={onAllOn} scale={0.95} ripple={false} style={{
            fontSize: 11, color: theme.primary, fontWeight: 600,
            padding: '2px 6px', borderRadius: 6, letterSpacing: '-0.01em',
          }}>전체 켜기</Press>
        </div>
        <div style={{ padding: '0 6px 8px' }}>
          {members.map(m => {
            const on = !hidden.has(m.name);
            return (
              <Press key={m.id} onClick={() => onToggle(m.name)} scale={0.98} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '8px 10px', borderRadius: 10,
              }}>
                <div style={{
                  width: 26, height: 26, borderRadius: '50%',
                  background: m.color, color: '#fff',
                  display: 'grid', placeItems: 'center',
                  fontSize: 13, opacity: on ? 1 : 0.4,
                  transition: 'opacity 200ms ease',
                }}>{m.emoji}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{
                    fontSize: 13, fontWeight: 600,
                    color: on ? theme.text : theme.textTertiary,
                    letterSpacing: '-0.01em',
                  }}>{m.name}</div>
                </div>
                <MiniToggle theme={theme} on={on} accent={m.color}/>
              </Press>
            );
          })}
        </div>
      </div>
    </>
  );
}

function MiniToggle({ theme, on, accent }) {
  return (
    <div style={{
      width: 34, height: 20, borderRadius: 10,
      background: on ? (accent || theme.primary) : theme.dividerStrong,
      position: 'relative', flexShrink: 0,
      transition: 'background 220ms ease',
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 16 : 2,
        width: 16, height: 16, borderRadius: '50%',
        background: '#fff',
        transition: 'left 220ms cubic-bezier(.3,.85,.3,1)',
        boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
      }}/>
    </div>
  );
}

Object.assign(window, { ScopeToggle, GroupDropdown, MemberPopover, MiniToggle });
