// ────────────────────────────────────────────────────────────
// 친구 / 그룹 segmented control
// ────────────────────────────────────────────────────────────
function SegmentTabs({ theme, tabs, active, onChange }) {
  return (
    <div style={{
      display: 'flex', padding: 4, gap: 4,
      background: theme.surface2, borderRadius: 14,
      border: `1px solid ${theme.divider}`,
    }}>
      {tabs.map((t) => {
        const on = t.id === active;
        return (
          <Press key={t.id} ripple={false} scale={0.97} onClick={() => onChange(t.id)} style={{
            flex: 1, height: 38, borderRadius: 10,
            display: 'grid', placeItems: 'center',
            background: on ? theme.surface : 'transparent',
            boxShadow: on ? theme.elevation.replace('32px', '14px') : 'none',
            transition: 'background 160ms ease',
          }}>
            <span style={{
              fontSize: 14, fontWeight: on ? 700 : 500,
              letterSpacing: '-0.01em',
              color: on ? theme.text : theme.textSecondary,
            }}>{t.label}</span>
          </Press>
        );
      })}
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// Friends screen — tabs: 친구 / 그룹
// ────────────────────────────────────────────────────────────
function FriendsScreen({ theme, members }) {
  const [tab, setTab] = React.useState('friends');
  return (
    <div style={{
      position: 'absolute', inset: 0, background: theme.bg,
      color: theme.text, display: 'flex', flexDirection: 'column',
    }}>
      {/* Segmented tabs */}
      <div style={{ padding: '14px 16px 4px' }}>
        <SegmentTabs theme={theme} active={tab} onChange={setTab}
          tabs={[{ id: 'friends', label: '친구' }, { id: 'group', label: '그룹' }]}/>
      </div>
      {tab === 'friends'
        ? <FriendsTab theme={theme} members={members}/>
        : <GroupTab theme={theme}/>}
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// 친구 tab — member list
// ────────────────────────────────────────────────────────────
function FriendsTab({ theme, members }) {
  const [copied, setCopied] = React.useState(false);
  const onCopy = () => { setCopied(true); setTimeout(() => setCopied(false), 1600); };
  return (
    <div style={{
      flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column',
    }}>
      {/* Header */}
      <div style={{ padding: '10px 20px 8px' }}>
        <div style={{
          fontSize: 22, fontWeight: 700, letterSpacing: '-0.03em', color: theme.text,
        }}>친구</div>
        <div style={{
          fontSize: 12, color: theme.textSecondary, marginTop: 4, letterSpacing: '-0.01em',
        }}>함께 캘린더를 쓰는 사람 {members.length}명</div>
      </div>

      {/* Invite card */}
      <div style={{ padding: '12px 16px 4px' }}>
        <div style={{
          background: theme.tint,
          borderRadius: 16, padding: 16,
          display: 'flex', flexDirection: 'column', gap: 14,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: theme.primary, color: theme.onPrimary,
              display: 'grid', placeItems: 'center',
            }}>
              <Icon name="share" size={18} color={theme.onPrimary}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: theme.text, letterSpacing: '-0.01em' }}>
                초대 링크로 친구 추가하기
              </div>
              <div style={{ fontSize: 11, color: theme.textSecondary, marginTop: 2, letterSpacing: '-0.01em' }}>
                링크를 받은 사람만 우리 캘린더에 참여할 수 있어요
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <div style={{
              flex: 1, height: 40, padding: '0 12px',
              borderRadius: 10, background: theme.surface,
              display: 'flex', alignItems: 'center',
              fontSize: 12, color: theme.textSecondary,
              fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace',
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}>ourcal.app/i/v8K3Qz</div>
            <Press onClick={onCopy} scale={0.94} style={{
              height: 40, padding: '0 14px',
              background: theme.primary, color: theme.onPrimary,
              borderRadius: 10, display: 'grid', placeItems: 'center',
              fontSize: 12.5, fontWeight: 600, letterSpacing: '-0.01em',
            }}>
              {copied ? '복사됨' : '복사'}
            </Press>
          </div>
        </div>
      </div>

      {/* Members list */}
      <div style={{ padding: '20px 20px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 11.5, fontWeight: 600, color: theme.textSecondary, letterSpacing: '0.02em' }}>
          멤버 {members.length}
        </div>
        <Press scale={0.94} ripple={false} style={{
          fontSize: 11.5, color: theme.primary, fontWeight: 600,
          padding: '4px 8px', borderRadius: 6, letterSpacing: '-0.01em',
        }}>관리</Press>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        {members.map((m, i) => (
          <Press key={m.id} scale={0.99} style={{
            display: 'flex', alignItems: 'center', gap: 12, padding: '14px 20px',
            borderBottom: i < members.length - 1 ? `1px solid ${theme.divider}` : 'none',
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: '50%',
              background: m.color, color: '#fff',
              display: 'grid', placeItems: 'center',
              fontSize: 18, fontWeight: 600,
            }}>{m.emoji}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 6,
                fontSize: 14.5, fontWeight: 600, color: theme.text, letterSpacing: '-0.01em',
              }}>
                <span>{m.name}</span>
                {m.role === '주인' && <Icon name="crown" size={13} color={theme.primary}/>}
              </div>
              <div style={{
                fontSize: 11.5, color: theme.textSecondary, marginTop: 2, letterSpacing: '-0.01em',
              }}>
                {m.role}
              </div>
            </div>
            <div style={{
              width: 28, height: 28, borderRadius: 14,
              display: 'grid', placeItems: 'center', color: theme.textTertiary,
            }}>
              <Icon name="chevR" size={16} color={theme.textTertiary}/>
            </div>
          </Press>
        ))}
        {/* Pending invite row */}
        <div style={{ padding: '14px 20px', borderTop: `1px solid ${theme.divider}` }}>
          <div style={{ fontSize: 11.5, fontWeight: 600, color: theme.textSecondary, letterSpacing: '0.02em', marginBottom: 10 }}>
            초대 대기 중 1
          </div>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{
              width: 44, height: 44, borderRadius: '50%',
              background: theme.surface2,
              display: 'grid', placeItems: 'center',
              border: `1.5px dashed ${theme.dividerStrong}`,
              color: theme.textTertiary,
            }}>
              <Icon name="user" size={20} color={theme.textTertiary}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: theme.text, letterSpacing: '-0.01em' }}>seojin@…</div>
              <div style={{ fontSize: 11.5, color: theme.textSecondary, marginTop: 2 }}>2일 전 초대됨</div>
            </div>
            <Press scale={0.94} ripple={false} style={{
              padding: '6px 12px', borderRadius: 8, background: theme.surface2,
              color: theme.textSecondary, fontSize: 12, fontWeight: 500,
            }}>취소</Press>
          </div>
        </div>
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// 그룹 tab — 그룹 관리
// ────────────────────────────────────────────────────────────
const SEED_GROUPS = [
  { id: 'home', name: '우리집',     role: '소유자', count: 3 },
  { id: 'work', name: '회사 팀',    role: '참여중', count: 2 },
  { id: 'uni',  name: '대학 친구들', role: '소유자', count: 4 },
];

function GroupTab({ theme }) {
  const [groups, setGroups] = React.useState(SEED_GROUPS);
  const danger = '#E34545';
  const dangerTint = theme.name === 'dark' ? 'rgba(227,69,69,0.18)' : '#FFEAEA';
  const leave = (id) => setGroups((g) => g.filter((x) => x.id !== id));
  const atMax = groups.length >= 5;

  return (
    <div style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}>
      {/* Header row */}
      <div style={{
        padding: '12px 20px 0', display: 'flex',
        alignItems: 'flex-start', justifyContent: 'space-between', gap: 16,
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.03em', color: theme.text }}>
            그룹 관리
          </div>
          <div style={{
            fontSize: 12, color: theme.textSecondary, marginTop: 6,
            letterSpacing: '-0.01em', lineHeight: 1.45, maxWidth: 240,
          }}>
            그룹은 최대 5개, 그룹원은 최대 5명까지 가능합니다.
          </div>
        </div>
        <Press scale={0.95} disabled={atMax} style={{
          flexShrink: 0, padding: '10px 18px', borderRadius: 12,
          background: atMax ? theme.surface2 : theme.primary,
          color: atMax ? theme.textTertiary : theme.onPrimary,
          display: 'flex', alignItems: 'center', gap: 5,
          fontSize: 14, fontWeight: 700, letterSpacing: '-0.01em',
        }}>
          <Icon name="plus" size={15} color={atMax ? theme.textTertiary : theme.onPrimary}/>
          추가
        </Press>
      </div>

      {/* Group list */}
      <div style={{ padding: '18px 16px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {groups.map((g) => {
          const owner = g.role === '소유자';
          return (
            <div key={g.id} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              background: theme.surface, borderRadius: 16,
              border: `1px solid ${theme.divider}`,
              padding: '16px 16px 16px 18px',
              boxShadow: theme.name === 'dark' ? 'none' : '0 1px 2px rgba(11,15,31,0.04)',
            }}>
              <div style={{
                width: 44, height: 44, borderRadius: 13, flexShrink: 0,
                background: theme.tint, color: theme.primary,
                display: 'grid', placeItems: 'center',
                fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em',
              }}>{g.name.slice(0, 1)}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  fontSize: 15.5, fontWeight: 700, color: theme.text,
                  letterSpacing: '-0.02em', whiteSpace: 'nowrap',
                  overflow: 'hidden', textOverflow: 'ellipsis',
                }}>{g.name}</div>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  marginTop: 4,
                }}>
                  {owner && <Icon name="crown" size={12} color={theme.primary}/>}
                  <span style={{
                    fontSize: 12, fontWeight: 500,
                    color: owner ? theme.primary : theme.textSecondary,
                    letterSpacing: '-0.01em',
                  }}>{g.role}</span>
                  <span style={{ fontSize: 12, color: theme.textTertiary }}>· 그룹원 {g.count}명</span>
                </div>
              </div>
              <Press scale={0.93} ripple={false} onClick={() => leave(g.id)} style={{
                flexShrink: 0, padding: '9px 16px', borderRadius: 11,
                background: dangerTint, color: danger,
                fontSize: 13.5, fontWeight: 700, letterSpacing: '-0.01em',
              }}>{owner ? '삭제' : '탈퇴'}</Press>
            </div>
          );
        })}

        {groups.length === 0 && (
          <div style={{
            marginTop: 40, textAlign: 'center', color: theme.textTertiary,
            fontSize: 13, letterSpacing: '-0.01em',
          }}>
            참여 중인 그룹이 없어요.<br/>
            <span style={{ color: theme.textSecondary }}>‘추가’를 눌러 새 그룹을 만들어 보세요.</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// Settings screen — my page
// ────────────────────────────────────────────────────────────
function SettingsRow({ theme, icon, label, sub, right, last, onClick, danger }) {
  return (
    <Press onClick={onClick} scale={0.99} style={{
      display: 'flex', alignItems: 'center', gap: 14,
      padding: '14px 20px',
      borderBottom: last ? 'none' : `1px solid ${theme.divider}`,
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: 9,
        background: danger ? '#FFEAEA' : theme.tint,
        color: danger ? '#E34545' : theme.primary,
        display: 'grid', placeItems: 'center', flexShrink: 0,
      }}>
        <Icon name={icon} size={16} color={danger ? '#E34545' : theme.primary}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 14, fontWeight: 500, color: danger ? '#E34545' : theme.text,
          letterSpacing: '-0.01em',
        }}>{label}</div>
        {sub && (
          <div style={{ fontSize: 11.5, color: theme.textSecondary, marginTop: 2, letterSpacing: '-0.01em' }}>
            {sub}
          </div>
        )}
      </div>
      {right || <Icon name="chevR" size={16} color={theme.textTertiary}/>}
    </Press>
  );
}

function SettingsSection({ theme, title, children, sub }) {
  return (
    <div style={{ marginTop: 16 }}>
      <div style={{
        fontSize: 11, fontWeight: 600, color: theme.textSecondary,
        padding: '0 20px 8px', letterSpacing: '0.04em', textTransform: 'uppercase',
      }}>{title}</div>
      <div style={{
        background: theme.surface,
        borderTop: `1px solid ${theme.divider}`,
        borderBottom: `1px solid ${theme.divider}`,
      }}>{children}</div>
      {sub && (
        <div style={{
          fontSize: 11, color: theme.textTertiary,
          padding: '8px 20px 0', letterSpacing: '-0.01em',
        }}>{sub}</div>
      )}
    </div>
  );
}

function Toggle({ theme, on, onChange }) {
  return (
    <Press
      ripple={false} scale={0.94}
      onClick={() => onChange(!on)}
      style={{
        width: 44, height: 26, borderRadius: 13,
        background: on ? theme.primary : theme.dividerStrong,
        position: 'relative', transition: 'background 200ms ease',
        flexShrink: 0,
      }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 20 : 2,
        width: 22, height: 22, borderRadius: '50%',
        background: '#fff', transition: 'left 220ms cubic-bezier(.3,.8,.3,1)',
        boxShadow: '0 2px 4px rgba(0,0,0,0.18)',
      }}/>
    </Press>
  );
}

function SettingsScreen({ theme, dark, setDark, notif, setNotif, weekStart, setWeekStart, fontScale }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, background: theme.surface2,
      color: theme.text, overflowY: 'auto',
    }}>
      {/* Header */}
      <div style={{ padding: '14px 20px 4px' }}>
        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.03em' }}>설정</div>
      </div>

      {/* Profile card */}
      <div style={{ padding: '14px 16px 0' }}>
        <Press scale={0.99} style={{
          background: theme.surface, borderRadius: 16, padding: 18,
          display: 'flex', alignItems: 'center', gap: 14,
          border: `1px solid ${theme.divider}`,
        }}>
          <div style={{
            width: 56, height: 56, borderRadius: '50%',
            background: `linear-gradient(135deg, ${theme.primary}, ${theme.primaryStrong})`,
            color: theme.onPrimary,
            display: 'grid', placeItems: 'center',
            fontSize: 22, fontWeight: 700,
          }}>나</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: theme.text, letterSpacing: '-0.02em' }}>
              내 캘린더
            </div>
            <div style={{ fontSize: 12, color: theme.textSecondary, marginTop: 2, letterSpacing: '-0.01em' }}>
              me@ourcal.app
            </div>
          </div>
          <Press scale={0.92} ripple={false} style={{
            width: 32, height: 32, borderRadius: 16, background: theme.surface2,
            display: 'grid', placeItems: 'center',
          }}>
            <Icon name="pencil" size={15} color={theme.text}/>
          </Press>
        </Press>
      </div>

      {/* General */}
      <SettingsSection theme={theme} title="일반">
        <SettingsRow theme={theme} icon="bell" label="알림" sub={notif ? '일정 30분 전 알림' : '꺼짐'}
          right={<Toggle theme={theme} on={notif} onChange={setNotif}/>}/>
        <SettingsRow theme={theme} icon="moon" label="다크 모드" sub={dark ? '항상 켜기' : '시스템 설정 따름'}
          right={<Toggle theme={theme} on={dark} onChange={setDark}/>}/>
        <SettingsRow theme={theme} icon="calendar" label="주 시작 요일" right={
          <Press scale={0.94} ripple={false} onClick={() => setWeekStart(weekStart === 0 ? 1 : 0)} style={{
            display: 'flex', alignItems: 'center', gap: 4,
            fontSize: 13, color: theme.textSecondary, fontWeight: 500,
          }}>
            <span>{weekStart === 0 ? '일요일' : '월요일'}</span>
            <Icon name="chevR" size={14} color={theme.textTertiary}/>
          </Press>
        } last/>
      </SettingsSection>

      {/* Display */}
      <SettingsSection theme={theme} title="표시" sub={`현재 글꼴 크기: ${fontScale === 1 ? '시스템 기본' : (fontScale * 100).toFixed(0) + '%'}`}>
        <SettingsRow theme={theme} icon="sparkle" label="글꼴" sub="기기 설정 사용" right={
          <span style={{ fontSize: 12.5, color: theme.textSecondary }}>시스템</span>
        }/>
        <SettingsRow theme={theme} icon="search" label="기본 화면" right={
          <span style={{ fontSize: 12.5, color: theme.textSecondary }}>월간 보기</span>
        } last/>
      </SettingsSection>

      {/* Account */}
      <SettingsSection theme={theme} title="계정">
        <SettingsRow theme={theme} icon="user" label="프로필 편집"/>
        <SettingsRow theme={theme} icon="lock" label="개인정보 보호"/>
        <SettingsRow theme={theme} icon="help" label="도움말 · 문의" last/>
      </SettingsSection>

      {/* Logout */}
      <SettingsSection theme={theme} title=" ">
        <SettingsRow theme={theme} icon="logout" label="로그아웃" danger last/>
      </SettingsSection>

      <div style={{
        textAlign: 'center', padding: '24px 0 100px',
        fontSize: 10.5, color: theme.textTertiary, letterSpacing: '-0.01em',
      }}>
        우리캘린더 v1.0.0
      </div>
    </div>
  );
}

Object.assign(window, { FriendsScreen, FriendsTab, GroupTab, SegmentTabs, SettingsScreen, SettingsRow, SettingsSection, Toggle });
