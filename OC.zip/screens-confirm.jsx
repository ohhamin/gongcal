// ────────────────────────────────────────────────────────────
// HeroIcon — Heroicons (outline, 24×24) used in the confirm dialog
// source: heroicons.com (MIT)
// ────────────────────────────────────────────────────────────
const HERO_PATHS = {
  'calendar-days': 'M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5m-9-6h.008v.008H12v-.008ZM12 15h.008v.008H12V15Zm0 2.25h.008v.008H12v-.008ZM9.75 15h.008v.008H9.75V15Zm0 2.25h.008v.008H9.75v-.008ZM7.5 15h.008v.008H7.5V15Zm0 2.25h.008v.008H7.5v-.008Zm6.75-4.5h.008v.008h-.008v-.008Zm0 2.25h.008v.008h-.008V15Zm0 2.25h.008v.008h-.008v-.008Zm2.25-4.5h.008v.008H16.5v-.008Zm0 2.25h.008v.008H16.5V15Z',
  'envelope-open': 'M21.75 9v.906a2.25 2.25 0 0 1-1.183 1.981l-6.478 3.488M2.25 9v.906a2.25 2.25 0 0 0 1.183 1.981l6.478 3.488m8.839 2.51-4.66-2.51m0 0-1.023-.55a2.25 2.25 0 0 0-2.134 0l-1.022.55m0 0-4.661 2.51m16.5 1.615a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V8.844a2.25 2.25 0 0 1 1.183-1.981l7.5-4.039a2.25 2.25 0 0 1 2.134 0l7.5 4.039a2.25 2.25 0 0 1 1.183 1.98V19.5Z',
  'check-circle': 'M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z',
};
function HeroIcon({ name = 'calendar-days', size = 24, color = 'currentColor', strokeWidth = 1.5 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      style={{ display: 'block' }}>
      <path d={HERO_PATHS[name] || HERO_PATHS['calendar-days']} />
    </svg>
  );
}

// ────────────────────────────────────────────────────────────
// ConfirmModal — 중앙 정렬 확인 다이얼로그
// 앱 스타일: 라운드 카드 · 네이비 프라이머리 · Press 피드백
// ────────────────────────────────────────────────────────────
function ConfirmModal({
  theme, open, onClose, onAccept, onDecline,
  icon = 'calendar-days',
  title = '이 일정 초대를 수락하시겠습니까?',
  desc,
  acceptLabel = '수락하기',
  declineLabel = '수락거절',
  instant,
}) {
  const [render, setRender] = React.useState(open);
  const [shown, setShown] = React.useState(!!instant && open);
  React.useEffect(() => {
    if (open && instant) { setRender(true); setShown(true); return; }
    if (open) {
      setRender(true);
      requestAnimationFrame(() => requestAnimationFrame(() => setShown(true)));
    } else if (render) {
      setShown(false);
      const t = setTimeout(() => setRender(false), 260);
      return () => clearTimeout(t);
    }
  }, [open]);
  if (!render) return null;

  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 360, display: 'grid', placeItems: 'center', padding: 20 }}>
      {/* backdrop */}
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: theme.backdrop,
        opacity: shown ? 1 : 0, transition: 'opacity 240ms ease',
      }} />
      {/* card */}
      <div style={{
        position: 'relative', width: 296, maxWidth: '100%',
        background: theme.surface, borderRadius: 22,
        boxShadow: theme.elevation,
        padding: '28px 22px 20px',
        textAlign: 'center',
        opacity: shown ? 1 : 0,
        transform: shown ? 'scale(1) translateY(0)' : 'scale(0.92) translateY(8px)',
        transition: 'opacity 240ms ease, transform 280ms cubic-bezier(.2,.85,.3,1.05)',
      }}>
        {/* icon */}
        {icon && (
          <div style={{
            width: 56, height: 56, borderRadius: 17, margin: '0 auto 16px',
            background: theme.tint, color: theme.primary,
            display: 'grid', placeItems: 'center',
          }}>
            <HeroIcon name={icon} size={28} color={theme.primary} strokeWidth={1.6} />
          </div>
        )}
        {/* title */}
        <div style={{
          fontSize: 16.5, fontWeight: 700, color: theme.text,
          letterSpacing: '-0.02em', lineHeight: 1.45, textWrap: 'balance',
        }}>{title}</div>
        {/* optional description */}
        {desc && (
          <div style={{
            fontSize: 12.5, color: theme.textSecondary, marginTop: 8,
            letterSpacing: '-0.01em', lineHeight: 1.5,
          }}>{desc}</div>
        )}
        {/* actions */}
        <div style={{ display: 'flex', gap: 9, marginTop: 22 }}>
          <Press onClick={onDecline || onClose} scale={0.96} style={{
            flex: 1, height: 48, borderRadius: 13,
            background: theme.surface2, color: theme.text,
            display: 'grid', placeItems: 'center',
            fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em',
          }}>{declineLabel}</Press>
          <Press onClick={onAccept || onClose} scale={0.96} style={{
            flex: 1, height: 48, borderRadius: 13,
            background: theme.primary, color: theme.onPrimary,
            display: 'grid', placeItems: 'center',
            fontSize: 14, fontWeight: 700, letterSpacing: '-0.01em',
            boxShadow: `0 4px 16px ${theme.primary}44`,
          }}>{acceptLabel}</Press>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ConfirmModal, HeroIcon });
