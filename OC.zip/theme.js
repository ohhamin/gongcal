// 우리캘린더 design tokens — Navy palette, light/dark
window.makeTheme = function(dark) {
  return dark ? {
    name: 'dark',
    bg: '#0B0F1F',
    surface: '#13192E',
    surface2: '#1A2140',
    tint: '#1A2447',      // navy soft tint
    primary: '#8DA4F2',   // navy accent in dark
    primaryStrong: '#A6B8F5',
    onPrimary: '#0B0F1F',
    text: '#F0F0F5',
    textSecondary: '#9B9BA8',
    textTertiary: '#6B6B7A',
    divider: 'rgba(255,255,255,0.08)',
    dividerStrong: 'rgba(255,255,255,0.14)',
    sunday: '#FF6B6B',
    saturday: '#7B9BFF',
    chip: '#1A2140',
    backdrop: 'rgba(0,0,0,0.55)',
    elevation: '0 8px 32px rgba(0,0,0,0.45)',
    pressedTint: 'rgba(255,255,255,0.08)',
  } : {
    name: 'light',
    bg: '#FFFFFF',
    surface: '#FFFFFF',
    surface2: '#F7F8FB',
    tint: '#E8EDFB',
    primary: '#1E3A8A',
    primaryStrong: '#162C6E',
    onPrimary: '#FFFFFF',
    text: '#111122',
    textSecondary: '#76768A',
    textTertiary: '#BABABF',
    divider: '#F0F0F5',
    dividerStrong: '#E0E0EB',
    sunday: '#E34545',
    saturday: '#3656C2',
    chip: '#F0F0F5',
    backdrop: 'rgba(11,15,31,0.42)',
    elevation: '0 8px 32px rgba(11,15,31,0.18)',
    pressedTint: 'rgba(11,15,31,0.06)',
  };
};

// Fixed seed data: May 2026 events
// keys are YYYY-MM-DD
window.SEED_EVENTS = {
  '2026-05-04': [{ title: '월요일 회의', time: '오전 10시', who: '나' }],
  '2026-05-05': [{ title: '어린이날', time: '종일', who: '공휴일', holiday: true }],
  '2026-05-06': [{ title: '카페 데이트', time: '오후 3시', who: '지우' }],
  '2026-05-10': [
    { title: '졸림', time: '종일', who: '나' },
    { title: '안녕하세요', time: '오전 10시', who: '민수' },
    { title: '공룡캘린더', time: '오후 2시', who: '나' },
  ],
  '2026-05-11': [{ title: '뻬에애', time: '종일', who: '지우' }],
  '2026-05-12': [{ title: '안녕', time: '종일', who: '민수' }],
  '2026-05-13': [{ title: '개인 운동', time: '오후 7시', who: '나', private: true }],
  '2026-05-15': [
    { title: '스승의 날', time: '종일', who: '공휴일', holiday: true },
    { title: '엄마 전화', time: '오후 8시', who: '나' },
  ],
  '2026-05-18': [{ title: '프로젝트 마감', time: '오후 11시', who: '민수' }],
  '2026-05-19': [{ title: '병원', time: '오전 11시', who: '지우', private: true }],
  '2026-05-20': [{ title: '저녁 약속', time: '오후 7시', who: '지우' }],
  '2026-05-21': [],
  '2026-05-25': [{ title: '치과', time: '오전 11시', who: '나' }],
  '2026-05-29': [{ title: '주말 여행', time: '종일', who: '지우' }, { title: '주말 여행', time: '종일', who: '민수' }],
  '2026-05-30': [{ title: '주말 여행', time: '종일', who: '지우' }],
};

window.MEMBERS = [
  { id: 'me',    name: '나',   color: '#1E3A8A', tint: '#E4E9F7', emoji: '🌙', online: true,  role: '주인',       group: 'me' },
  { id: 'jiwoo', name: '지우', color: '#C03A4B', tint: '#FBE6E9', emoji: '🌸', online: true,  role: '편집 가능', group: 'g1' },
  { id: 'minsu', name: '민수', color: '#3E7E48', tint: '#E1EFE3', emoji: '🌲', online: false, role: '편집 가능', group: 'g1' },
  { id: 'hara',  name: '하라', color: '#A8580E', tint: '#F5E6D6', emoji: '🍊', online: false, role: '읽기 전용', group: 'g2' },
];

// Holiday red palette
window.HOLIDAY_COLOR = '#D63B3B';
window.HOLIDAY_TINT  = '#FCE4E4';

// 캘린더 그룹 정의 — 우측 상단 드롭다운에서 선택
window.CALENDAR_GROUPS = [
  { id: 'mine', label: '나만보기', sub: '내 일정만', icon: '🌙', members: ['나'] },
  { id: 'g1',   label: '우리집',   sub: '지우 · 민수와 함께', icon: '🏠', members: ['나', '지우', '민수'] },
  { id: 'g2',   label: '회사 팀',  sub: '하라 외 1명', icon: '💼', members: ['나', '하라'] },
];
