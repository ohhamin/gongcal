// Press — universal touch-press feedback with scale + ripple
function Press({ as: Tag = 'div', onClick, children, style, ripple = true, scale = 0.96, disabled = false, ...rest }) {
  const [pressed, setPressed] = React.useState(false);
  const [ripples, setRipples] = React.useState([]);
  const ref = React.useRef(null);
  const handleDown = (e) => {
    if (disabled) return;
    setPressed(true);
    if (!ripple || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = (e.clientX || (e.touches && e.touches[0]?.clientX) || rect.left + rect.width/2) - rect.left;
    const y = (e.clientY || (e.touches && e.touches[0]?.clientY) || rect.top + rect.height/2) - rect.top;
    const id = Math.random();
    setRipples((r) => [...r, { id, x, y }]);
    setTimeout(() => setRipples((r) => r.filter(x => x.id !== id)), 600);
  };
  const handleUp = () => setPressed(false);
  return (
    <Tag
      ref={ref}
      onPointerDown={handleDown}
      onPointerUp={handleUp}
      onPointerLeave={handleUp}
      onPointerCancel={handleUp}
      onClick={disabled ? undefined : onClick}
      style={{
        position: 'relative',
        overflow: 'hidden',
        cursor: disabled ? 'default' : 'pointer',
        transform: `scale(${pressed ? scale : 1})`,
        transition: 'transform 120ms cubic-bezier(.2,.7,.2,1)',
        WebkitTapHighlightColor: 'transparent',
        touchAction: 'manipulation',
        userSelect: 'none',
        ...style,
      }}
      {...rest}
    >
      {children}
      {ripple && ripples.map(r => (
        <span key={r.id} style={{
          position: 'absolute', left: r.x, top: r.y,
          width: 0, height: 0, borderRadius: '50%',
          background: 'currentColor', opacity: 0.18, pointerEvents: 'none',
          transform: 'translate(-50%,-50%)',
          animation: 'oc-ripple 550ms ease-out forwards',
        }}/>
      ))}
    </Tag>
  );
}

// Bottom tab bar (3 tabs)
function BottomTabs({ tab, setTab, theme, platform }) {
  const tabs = [
    { id: 'calendar', label: '캘린더', icon: 'calendar', iconF: 'calendarFill' },
    { id: 'friends',  label: '친구',   icon: 'users',    iconF: 'usersFill' },
    { id: 'settings', label: '설정',   icon: 'settings', iconF: 'settingsFill' },
  ];
  const padBottom = platform === 'ios' ? 24 : 8;
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0,
      paddingBottom: padBottom, paddingTop: 6,
      background: theme.surface,
      borderTop: `1px solid ${theme.divider}`,
      display: 'flex', justifyContent: 'space-around',
      zIndex: 30,
    }}>
      {tabs.map(t => {
        const active = tab === t.id;
        return (
          <Press
            key={t.id}
            onClick={() => setTab(t.id)}
            scale={0.92}
            ripple={false}
            style={{
              flex: 1, padding: '6px 4px',
              display: 'flex', flexDirection: 'column', alignItems: 'center',
              gap: 3, color: active ? theme.primary : theme.textTertiary,
            }}
          >
            <Icon name={active ? t.iconF : t.icon} size={24} color={active ? theme.primary : theme.textTertiary} />
            <span style={{
              fontSize: 10.5, fontWeight: active ? 600 : 500,
              letterSpacing: '-0.01em',
            }}>{t.label}</span>
          </Press>
        );
      })}
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// Splash
// ────────────────────────────────────────────────────────────
function Splash({ theme, onEnter }) {
  const [phase, setPhase] = React.useState('enter');
  React.useEffect(() => {
    const t1 = setTimeout(() => setPhase('show'), 60);
    const t2 = setTimeout(() => setPhase('exit'), 2200);
    const t3 = setTimeout(() => onEnter && onEnter(), 2700);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);
  const show = phase === 'show';
  const exit = phase === 'exit';
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 100,
      background: theme.bg,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      gap: 28,
      opacity: exit ? 0 : 1,
      transition: 'opacity 480ms ease',
    }}>
      {/* logo */}
      <div style={{
        position: 'relative', width: 88, height: 88,
        transform: show ? 'scale(1)' : 'scale(0.7)',
        opacity: show ? 1 : 0,
        transition: 'transform 700ms cubic-bezier(.2,.9,.3,1.2), opacity 500ms ease',
      }}>
        {/* logo mark — stacked navy squares forming a calendar leaf */}
        <div style={{
          position: 'absolute', inset: 0, borderRadius: 22,
          background: theme.primary,
          boxShadow: `0 12px 32px ${theme.primary}55`,
        }}/>
        <div style={{
          position: 'absolute', left: 16, top: 12, width: 56, height: 8, borderRadius: 4,
          background: theme.onPrimary, opacity: 0.55,
        }}/>
        <div style={{
          position: 'absolute', left: 16, top: 28, width: 24, height: 24, borderRadius: 6,
          background: theme.onPrimary,
        }}/>
        <div style={{
          position: 'absolute', left: 44, top: 28, width: 28, height: 8, borderRadius: 4,
          background: theme.onPrimary, opacity: 0.7,
        }}/>
        <div style={{
          position: 'absolute', left: 44, top: 40, width: 20, height: 8, borderRadius: 4,
          background: theme.onPrimary, opacity: 0.4,
        }}/>
        <div style={{
          position: 'absolute', left: 16, top: 58, width: 56, height: 14, borderRadius: 7,
          background: theme.onPrimary, opacity: 0.85,
        }}/>
      </div>
      {/* text */}
      <div style={{
        textAlign: 'center',
        transform: show ? 'translateY(0)' : 'translateY(12px)',
        opacity: show ? 1 : 0,
        transition: 'transform 700ms cubic-bezier(.2,.9,.3,1) 120ms, opacity 600ms ease 120ms',
      }}>
        <div style={{
          fontSize: 26, fontWeight: 700, color: theme.text,
          letterSpacing: '-0.04em', marginBottom: 8,
        }}>우리캘린더</div>
        <div style={{
          fontSize: 13, color: theme.textSecondary, letterSpacing: '-0.01em',
        }}>함께 쓰는 우리만의 캘린더</div>
      </div>
      {/* footer */}
      <div style={{
        position: 'absolute', bottom: 64, left: 0, right: 0, textAlign: 'center',
        fontSize: 11, color: theme.textTertiary, letterSpacing: '-0.01em',
        opacity: show && !exit ? 1 : 0, transition: 'opacity 400ms ease',
      }}>v 1.0.0 · ourcal team</div>
    </div>
  );
}

Object.assign(window, { Press, BottomTabs, Splash });
